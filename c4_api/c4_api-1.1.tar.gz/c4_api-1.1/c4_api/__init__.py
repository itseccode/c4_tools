# curl -u user:pass -k https://172.16.10.1:444/api-v1-objects/config
import argparse
import os
import sys
module_abspath = os.path.dirname(os.path.abspath(__file__))
os.environ['OPENSSL_CONF'] = f'{module_abspath}/openssl.cnf'
os.environ['OPENSSL_ENGINE_PATH'] = module_abspath

import pycurl
import certifi
from io import BytesIO
import json

class ApiConnector:
    def __init__(self, ip, port, user, password):
        self._base_url_server = f'https://{ip}:{port}/api-v1-server'
        self._base_url_objects = f'https://{ip}:{port}/api-v1-objects'
        self._user = user
        self._password = password
        self.__confidential_fields__ = [
            'password',
            'password_ssha',
            'password_sha512',
            '_auth_pass',
            'user',
            'auth_login',
            'community_name',
            'pubkey'
        ]

    def __parse_json(self, buffer):
        json_obj = {}
        try:
            json_obj = json.loads(buffer.getvalue().decode('utf-8'))
        except:
            print("Ошибка парсинга JSON")
        return json_obj

    def __remove_fields__(self, obj, fields):
        if not obj or type(obj) != dict:
            return

        for field in fields:
            if field in obj.keys(): del obj[field]

    def __get_curl_obj(self):
        curl_obj = pycurl.Curl()
        curl_obj.setopt(curl_obj.CONNECTTIMEOUT, 10)
        curl_obj.setopt(curl_obj.SSL_VERIFYPEER, False)
        curl_obj.setopt(curl_obj.SSL_VERIFYHOST, False)
        curl_obj.setopt(curl_obj.CAINFO, certifi.where())
        curl_obj.setopt(curl_obj.USERPWD, f"{self._user}:{self._password}")
        return curl_obj

    def __get_master_uuid(self):
        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_objects}/config')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()
        config_obj = self.__parse_json(_buffer)

        master_uuid = None
        for cfg in config_obj['data']:
            if cfg['subtype'] == 'master':
                master_uuid = cfg['uuid']
                break

        return master_uuid

    def __progress__(self, i, max_i, size):
        progress_percent = max_i / size
        progress = round(i / progress_percent)
        str_filler = "█" * progress
        str_emptiness = " " * (size - progress)
        sys.stdout.write(f"|\033[92m{str_filler}{str_emptiness}\033[0m| \033[1m{i} / {max_i}\033[0m")
        sys.stdout.flush()
        sys.stdout.write("\033[G")
        if i == max_i:
            sys.stdout.write("\n")

    def user_permissions(self, buffer = None):
        """
        Возвращает объект, определяющий права текущего пользователя.

        Returns:
            возвращает словарь, в котором описаны права.
        """
        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_server}/current-user-permissions')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()
        return self.__parse_json(_buffer)

    def get_config_objs(self):
        """
        Возвращает объекты со свойствами конфигураций.

        Args:
            buffer: i/o буфер, в который будет записан ответ. По умолчанию None.
        Returns:
            возвращает словарь.
        """
        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_objects}/config')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()
        return self.__parse_json(_buffer)


    def get_config_by_uuid(self, uuid, remove_confidential_fields = True):
        """
        Возвращает конфигурацию по идентификатору.

        Args:
            uuid: Идентификатор необходимой конфигурации.
            remove_confidential_fields: Логический параметр, отвечающий за удаление чувствительных полей. По умолчанию True.
        Returns:
            возвращает словарь.
        """

        if not uuid:
            print("Не указан UUID")
            return

        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_server}/config/{uuid}/export-config?view=full')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()

        config_obj = self.__parse_json(_buffer)
        if remove_confidential_fields and 'objects' in config_obj.keys():
            for obj in config_obj['objects']:
                self.__remove_fields__(obj, self.__confidential_fields__)

        return config_obj

    def get_master_config(self, remove_confidential_fields = True):
        """
        Возвращает master конфигурацию.

        Args:
            remove_confidential_fields: Логический параметр, отвечающий за удаление чувствительных полей. По умолчанию True.
        Returns:
            возвращает словарь.
        """
        master_uuid = self.__get_master_uuid()
        if not master_uuid:
            return

        return self.get_config_by_uuid(master_uuid, remove_confidential_fields)

    def get_cgw_obj(self):
        """
        Возвращает объекты со свойствами УБ.

        Returns:
            возвращает словарь.
        """
        master_uuid = self.__get_master_uuid()
        if not master_uuid:
            return

        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_objects}/config/{master_uuid}/cgw')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()
        return self.__parse_json(_buffer)

    def print_cgws(self):
        """
        Печатает список УБ.
        """
        master_uuid = self.__get_master_uuid()
        if not master_uuid:
            return

        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_objects}/config/{master_uuid}/cgw')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()

        cgws = self.__parse_json(_buffer)
        for cgw in cgws['data']:
            print(f"Name: {cgw['name']}, hwserial: {cgw['hwserial']}")

    def install_policy_cgw(self, hwserial_list):
        """
        Запускает процесс установки политики на УБ c определёнными hwserial.

        Args:
            hwserial_list: список hwserial УБ для установки политики.
        """
        master_uuid = self.__get_master_uuid()
        if not master_uuid:
            return

        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_server}/config/{master_uuid}/install-policy')
        c.setopt(c.POSTFIELDS, json.dumps({'target': hwserial_list}))
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()
        return self.__parse_json(_buffer)

    def install_policy_all(self):
        """
        Запускает процесс установки политики на все УБ в конфигурации.
        """
        master_uuid = self.__get_master_uuid()
        if not master_uuid:
            return

        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_objects}/config/{master_uuid}/cgw')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()

        cgws = self.__parse_json(_buffer)
        hwserial_list = []
        for cgw in cgws['data']:
            hwserial_list.append(cgw['hwserial'])

        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_server}/config/{master_uuid}/install-policy')
        c.setopt(c.POSTFIELDS, json.dumps({'target': hwserial_list}))
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()
        return self.__parse_json(_buffer)

    def get_cgw_config_by_hwserial(self, hwserial, remove_confidential_fields = True):
        """
        Возвращает конфигурацию УБ по hwserial.

        Args:
            hwserial: Идентификатор УБ.
            remove_confidential_fields: Логический параметр, отвечающий за удаление чувствительных полей. По умолчанию True.
        Returns:
            Возвращает словарь.
        """
        if not hwserial:
            print("Не указан hwserial")
            return

        master_uuid = self.__get_master_uuid()
        if not master_uuid:
            return

        _buffer = BytesIO()
        c = self.__get_curl_obj()
        c.setopt(c.URL, f'{self._base_url_server}/config/{master_uuid}/export-config-for-cgw/{hwserial}?view=full')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        c.close()

        config_obj = self.__parse_json(_buffer)
        if remove_confidential_fields and 'objects' in config_obj.keys():
            for obj in config_obj['objects']:
                self.__remove_fields__(obj, self.__confidential_fields__)

        return config_obj

    def get_all_cgw_configs(self, configs_write_path, remove_confidential_fields = True):
        """
        Собирает конфигурации всех УБ и записывает в файлы.

        Args:
            configs_write_path: Путь до директории, в которой будут созданы файлы с конфигурациями.
            remove_confidential_fields: Логический параметр, отвечающий за удаление чувствительных полей. По умолчанию True.
        """
        if not configs_write_path:
            print("Не задана директория")
            return

        if not os.path.exists(configs_write_path):
            print("Директория не существует")
            return

        cgws = self.get_cgw_obj()
        len_cgws = len(cgws)
        i = 0
        for cgw in cgws['data']:
            self.__progress__(i + 1, len_cgws, 40)
            i += 1
            filename = f"{cgw['name']}_{cgw['hwserial']}_config.json"
            with open(os.path.join(configs_write_path, filename), 'w') as f:
                json_data = self.get_cgw_config_by_hwserial(cgw['hwserial'], remove_confidential_fields)
                json.dump(json_data, f, indent=4, ensure_ascii=False)

        print("Выполнено")


def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\npython {os.path.basename(sys.argv[0])}",
            description = 'Утилита для экспорта конфигурации из Континент 4.\n\tprint_cgws - вывести список УБ с их hwserial.\n\tget_all_cgw_configs - получить конфигурации всех УБ.\n\tget_cgw_config_by_hwserial - получить конфигурацию УБ по hwserial.\n\tinstall_policy_all - установить политику на все узлы конфигурации.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 print_cgws
example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 get_all_cgw_configs --output_path /path/to/folder
example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 get_cgw_config_by_hwserial --hwserial 1 --output_path /path/to/folder
example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 install_policy_all
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('cmd', choices=['get_all_cgw_configs', 'get_cgw_config_by_hwserial', 'print_cgws', 'install_policy_all'])
    parser.add_argument('--output_path', help='Путь до папки для сохранения конфигураций.\n(get_all_cgw_configs, get_cgw_config_by_hwserial)', type=str)
    parser.add_argument('--hwserial', help='hwserial для получения конфигурации конкретного УБ. (get_cgw_config_by_hwserial)', type=str)
    parser.add_argument('--with_confidential_data', help='Выгружать конфигурацию с чувствительной информацией. По умолчанию выключено.', action=argparse.BooleanOptionalAction)
    args = parser.parse_args()

    if not args.cmd:
        parser.print_help()
        return

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('Неверный формат реквизитов')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = ApiConnector(args.ip, args.port, user, password)

    remove_confidential_fields = not args.with_confidential_data

    if args.cmd == 'print_cgws':
        api.print_cgws()

    if args.cmd == 'get_all_cgw_configs':
        api.get_all_cgw_configs(args.output_path,  remove_confidential_fields)

    if args.cmd == 'get_cgw_config_by_hwserial':
        full_path = os.path.join(args.output_path, f"{args.hwserial}_config.json")
        with open(full_path, 'w') as f:
            json_data = api.get_cgw_config_by_hwserial(args.hwserial, remove_confidential_fields)
            json.dump(json_data, f, indent=4, ensure_ascii=False)

    if args.cmd == 'install_policy_all':
        api.install_policy_all()