from setuptools import setup
setup(name = 'c4_api',
    version = '1.1',
    py_modules = ['c4_api'],
    packages = ['c4_api'],
    install_requires = ['pycurl'],
    include_package_data = True,
    package_data = {'': ['openssl.cnf', 'gost.so']},
    entry_points = {
        'console_scripts': [
                'c4_api = c4_api:cli',
        ]
    }
)
