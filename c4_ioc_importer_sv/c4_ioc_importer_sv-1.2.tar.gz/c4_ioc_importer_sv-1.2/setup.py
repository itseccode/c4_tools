from setuptools import setup
name = 'c4_ioc_importer_sv'
setup(name = name,
    version = '1.2',
    py_modules = [name],
    packages = [name],
    install_requires = ['c4_lib'],
    include_package_data = True,
    entry_points = {
        'console_scripts': [
                f'{name} = {name}.__main__:cli',
        ]
    }
)
