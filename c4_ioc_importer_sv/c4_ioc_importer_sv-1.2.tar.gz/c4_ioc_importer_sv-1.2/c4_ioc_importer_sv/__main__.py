#!/usr/bin/env python3
import argparse
import os
import sys
import json
import socket
import c4_lib


def draw_progress(i, min_i, max_i, size):
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[92m{str_filler}{str_emptiness}\033[0m| \033[1m{i - min_i} / {max_i - min_i} - {percent}%\033[0m")
    sys.stdout.flush()
    if i == max_i:
        sys.stdout.write("\n")


def valid_ip(address):
    try:
        socket.inet_aton(address)
        return True
    except:
        return False


def add_netobject(api, name, current_addr, config_uuid):
    """
    Добавляет сетевой объект в конфиг с определённым uuid, если объект существует, то только возвращет его uuid.

    Args:
        name: имя объекта
        current_addr: ip адрес
    Returns:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/netobject'

    fields = {'name': name, 'description': '', 'subtype': 'ip', 'ip': current_addr}
    netobj_data = api.post_to_endpoint(url, fields)

    # Если объект уже есть, возвращаем его uuid
    uuid = {}
    if 'name' in netobj_data.keys():
        objects = api.get_from_endpoint(url)
        for netobject in objects['data']:
            if netobject['name'] == name:
                uuid = netobject['uuid']
    else:
        uuid = netobj_data['uuid']
    return uuid


def add_netobject_group(api, name, config_uuid):
    """
    Добавляет группу сетевых объектов.

    Args:
        name: имя объекта
    Returns:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group'

    groups = api.get_from_endpoint(url)
    if type(groups) is dict:
        for group in groups.get('data', []):
            if group.get('name') == name:
                return group.get('uuid')

    fields = {'name': name, 'description': '', 'subtype': 'netobject'}
    obj_data = api.post_to_endpoint(url, fields)

    if api.result_check(obj_data):
        return obj_data['uuid']
    return None


def add_appfilter(api, name, url_regex, urlpath_regexes, filter_type, config_uuid):
    """
    Добавляет web фильтр.

    Args:
        name: имя объекта.
        url_regex: регулярное выражение url пути.
        urlpath_regexes: список регулярных выражений хостов.
        filter_type: протокол: http, https, ftp.
    Returns:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/appfilter'

    appfilters = api.get_from_endpoint(url)
    if type(appfilters) is dict:
        for appfilter in appfilters.get('data', []):
            if appfilter.get('name') == name:
                return appfilter.get('uuid')

    fields = {
        'name': '',
        'description': name,
        'url_regex': url_regex,
        'filter_type': filter_type,
        'urlpath_regexes': urlpath_regexes,
        'methods': [],
        'mime_types': []
    }
    obj_data = api.post_to_endpoint(url, fields)

    if api.result_check(obj_data):
        return obj_data['uuid']
    return None


def add_appfilter_group(api, name, filter_type, config_uuid, description=''):
    """
    Добавляет группу web фильтров.

    Args:
        name: имя объекта.
        filter_type: протокол: http, https, ftp.
        description: описание.
    Returns:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group'

    groups = api.get_from_endpoint(url)
    if type(groups) is dict:
        for group in groups.get('data', []):
            if group.get('name') == name:
                return group.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'subtype': 'appfilter',
        'params': {
            'filter_type': filter_type,
            'type': 'appfilter',
            'tag': 'custom_url'
        }
    }
    obj_data = api.post_to_endpoint(url, fields)

    if api.result_check(obj_data):
        return obj_data['uuid']
    return None


def add_dnsrecord(api, name, idn, config_uuid, description=''):
    """
    Добавляет dns запись.

    Args:
        name: имя объекта.
        idn: доменное имя.
        description: описание.
    Returns:
        Возвращает uuid при успешном добавлении.
    """
    if valid_ip(idn):
        return None

    url = f'{api.get_obj_url(config_uuid)}/dnsrecord'

    records = api.get_from_endpoint(url)
    if type(records) is dict:
        for record in records.get('data', []):
            if record.get('name') == name:
                return record.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'idn': idn
    }
    obj_data = api.post_to_endpoint(url, fields)

    if api.result_check(obj_data):
        return obj_data['uuid']
    return None


def add_dnsrecord_group(api, name, config_uuid, description=''):
    """
    Добавляет группу DNS записей.

    Args:
        name: имя объекта.
        description: описание.
    Returns:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group'

    groups = api.get_from_endpoint(url)
    if type(groups) is dict:
        for group in groups.get('data', []):
            if group.get('name') == name:
                return group.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'subtype': 'dnsrecord'
    }
    obj_data = api.post_to_endpoint(url, fields)

    if api.result_check(obj_data):
        return obj_data['uuid']
    return None


def add_to_group(api, uuid, members, config_uuid):
    """
    Добавляет объекты в группу.

    Args:
        uuid: идентификатор группы.
        members: список идентификаторов объектов.
    Returns:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group/{uuid}'
    api.result_check(
        api.put_to_endpoint(url, {'members': members})
    )


def remove_bof(input_file):
    input_filename = os.path.basename(input_file)
    out_name = f"clear_{input_filename}"
    with open(input_file, "rb") as f, open(out_name, 'wb') as out_f:
        line = f.readline().replace(b'\xef\xbb\xbf', b'')
        out_f.write(line)

        while not line == b'':
            line = f.readline().replace(b'\xef\xbb\xbf', b'')
            out_f.write(line)

    return out_name


def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для импорта индикаторов компрометации в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -c ioc.json
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('-i','--ioc', help='Путь до файла с индикаторами компрометации.', type=str)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    ioc_data = {}

    if args.ioc is None or not os.path.exists(args.ioc):
        print('[\033[91;1m-\033[0m] Файл настроек отсутствует.')
        return

    clear_file = remove_bof(args.ioc)
    with open(clear_file, 'r') as f:
        ioc_data = json.load(f)

    os.unlink(clear_file)

    ioc = ioc_data.get('ioc', {})
    hashes = ioc.get('hashes', [])
    urls = ioc.get('urls', [])
    ips = ioc.get('ips', [])
    domains = ioc.get('domains', [])

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    config_lock_data = api.config_lock_user()
    if config_lock_data['admin'] != None:
        print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        return

    api.set_config_lock()
    fork_data = api.fork_config()
    if not type(fork_data) is dict or 'uuid' not in fork_data.keys():
        print('[\033[91;1m-\033[0m] Ошибка блокировки конфига.')
        for msg in fork_data.get('__all__', []):
            print(f"\t{msg.get('message', '')}")
        api.free_config_lock()
        return

    config_uuid = fork_data['uuid']

    print(f"[*] Очистка устаревших данных.")
    url = f'{api.get_obj_url(config_uuid)}/group'
    groups = api.get_from_endpoint(url)
    if type(groups) is dict:
        for group in groups.get('data', []):
            if group.get('name') in ['IoC_SV_IP', 'IoC_SV_URL_http', 'IoC_SV_URL_https', 'IoC_SV_URL_ftp', 'IoC_SV_domains']:
                print(f"[*] {group.get('name')}")
                members = group.get('members', [])
                max_i = len(members)
                i = 0
                for member in members:
                    draw_progress(i, 0, max_i, 40)
                    i += 1
                    api.delete_obj(f"{api.get_obj_url(config_uuid)}/{member.get('type')}", member.get('uuid'))
                api.delete_obj(url, group.get('uuid'))
    print('[\033[92;1m+\033[0m] Очистка завершена.\n')

    del groups

    len_ips = len(ips)
    if len_ips > 0:
        print(f"[*] Импорт {len_ips} вредоносных хостов.")
        i = 0
        malicious_hosts_uuids = []
        for host in ips:
            draw_progress(i, 0, len_ips, 40)
            i += 1
            uuid = add_netobject(api, f"IoC_SV_{host['ip']}", host['ip'], config_uuid)
            if not uuid is None:
                malicious_hosts_uuids.append(uuid)

        grp_uuid = add_netobject_group(api, 'IoC_SV_IP', config_uuid)
        if not grp_uuid is None:
            add_to_group(api, grp_uuid, malicious_hosts_uuids, config_uuid)
        print('[\033[92;1m+\033[0m] Импорт вредоносных хостов завершен.\n')

    len_urls = len(urls)
    if len_urls > 0:
        print(f"[*] Импорт {len_urls} вредоносных URL.")
        i = 0
        malicious_http_uuids = []
        malicious_https_uuids = []
        malicious_ftp_uuids = []
        for url in urls:
            draw_progress(i, 0, len_urls, 40)
            i += 1
            filter_type = url['url'].split('://')[0]
            filter_type = filter_type.lower()
            if not filter_type in ['http', 'https', 'ftp']:
                print(f'[\033[91;1m-\033[0m] Неправильный протокол {filter_type}.')
                continue

            host_and_path = url['url'].split('://')[1]
            urlpath_regexes = [host_and_path[host_and_path.find('/'):]]
            url_regex = host_and_path[:host_and_path.find('/')]

            uuid = add_appfilter(api, f"IoC_SV_{url_regex}", url_regex, urlpath_regexes, filter_type, config_uuid)
            if uuid is None:
                continue

            if filter_type == 'http':
                malicious_http_uuids.append(uuid)
            elif filter_type == 'https':
                malicious_https_uuids.append(uuid)
            elif filter_type == 'ftp':
                malicious_ftp_uuids.append(uuid)

        if len(malicious_http_uuids) > 0:
            grp_uuid = add_appfilter_group(api, 'IoC_SV_URL_http', 'http', config_uuid)
            if not grp_uuid is None:
                add_to_group(api, grp_uuid, malicious_http_uuids, config_uuid)

        if len(malicious_https_uuids) > 0:
            grp_uuid = add_appfilter_group(api, 'IoC_SV_URL_https', 'https', config_uuid)
            if not grp_uuid is None:
                add_to_group(api, grp_uuid, malicious_https_uuids, config_uuid)

        if len(malicious_ftp_uuids) > 0:
            grp_uuid = add_appfilter_group(api, 'IoC_SV_URL_ftp', 'ftp', config_uuid)
            if not grp_uuid is None:
                add_to_group(api, grp_uuid, malicious_ftp_uuids, config_uuid)

        print('[\033[92;1m+\033[0m] Импорт вредоносных URL завершен.\n')


    len_domains = len(domains)
    if len_domains > 0:
        print(f"[*] Импорт {len_domains} вредоносных FQDN.")
        i = 0
        malicious_domains = []
        for domain in domains:
            draw_progress(i, 0, len_domains, 40)
            i += 1

            fqdn = domain.get('domain')
            uuid = add_dnsrecord(api, f"IoC_SV_{fqdn}", fqdn, config_uuid)
            if uuid is None:
                continue

            malicious_domains.append(uuid)

        if len(malicious_domains) > 0:
            grp_uuid = add_dnsrecord_group(api, 'IoC_SV_domains', config_uuid)
            if not grp_uuid is None:
                add_to_group(api, grp_uuid, malicious_domains, config_uuid)

        print('[\033[92;1m+\033[0m] Импорт вредоносных FQDN завершен.\n')


    len_hashes = len(hashes)
    if len_hashes > 0:
        i = 0
        print(f"[*] Импорт {len_hashes} пользовательских хэшей.")
        user_hashes_obj = []
        for hash in hashes:
            draw_progress(i, 0, len_hashes, 40)
            i += 1
            user_hashes_obj.append(
                {
                    'name': hash.get('filename', ''),
                    'md5': hash.get('md5', ''),
                    'size': hash.get('filesize', 0)
                }
            )

        tempfile_name = "hashes.json"
        with open(tempfile_name, 'w') as f:
            json.dump(user_hashes_obj, f, indent=4, ensure_ascii=False)

        result = api.post_to_endpoint(f"{api._base_url_server}/upload-userfs", {'filename': tempfile_name}, {'file': open(tempfile_name, 'rb')})
        if '__all__' in result.keys():
            print('[\033[91;1m-\033[0m] Ошибка импорта пользовательских хэшей.')
            for msg in fork_data.get('__all__', []):
                print(f"\t{msg.get('message', '')}")
        else:
            print('[\033[92;1m+\033[0m] Импорт пользовательских хэшей завершен.\n')

        os.unlink(tempfile_name)

    api.commit_config(config_uuid)
    api.free_config_lock()
    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")

