from setuptools import setup
setup(name = 'c4_rules_maker',
    version = '1.1',
    py_modules = ['c4_rules_maker'],
    packages = ['c4_rules_maker'],
    install_requires = ['c4_lib'],
    include_package_data = True,
    entry_points = {
        'console_scripts': [
                'c4_rules_maker = c4_rules_maker.__main__:cli',
        ]
    }
)
