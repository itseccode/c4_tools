#!/usr/bin/env python3
import argparse
import os
import sys
import json
import ipaddress

import c4_lib

def draw_progress(i, min_i, max_i, size):
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[92m{str_filler}{str_emptiness}\033[0m| \033[1m{i - min_i} / {max_i - min_i} - {percent}%\033[0m")
    sys.stdout.flush()
    if i == max_i:
        sys.stdout.write("\n")

def add_test_netobject(api, name, current_addr, config_uuid):
    url = f'{api.get_obj_url(config_uuid)}/netobject'
    ip = current_addr.exploded
    while ip.endswith('.255') or ip.endswith('.0'):
        current_addr += 1
        ip = current_addr.exploded

    fields = {'name': name, 'description': '', 'subtype':'ip', 'ip': ip}
    netobj_data = api.post_to_endpoint(url, fields)

    # Если объект уже есть, возвращаем его uuid
    if 'name' in netobj_data.keys():
        objects = api.get_from_endpoint(url)
        for netobject in objects['data']:
            if netobject['name'] == name:
                uuid = [netobject['uuid']]
    else:
        uuid = [netobj_data['uuid']]
    current_addr += 1
    return uuid, current_addr

def add_test_rule(api, name, src, dst, logging, config_uuid):
    """
    Создаёт правило фильтрации в конфиге с определённым uuid.

    Args:
        name: имя правила.
        src: список идентификаторов объектов-источников.
        dst: список идентификаторов объектов назначения.
        logging: логическое значение, определяющее включено ли логирование для правила.
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает словарь с uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/fwrule'
    fields = {
        'type': 'fwrule',
        'name': name,
        'src':src,
        'dst':dst,
        'rule_action':'block',
        'logging': logging,
        'rule_position': {'last': True}
    }
    return api.post_to_endpoint(url, fields)

def cli():
    config =  {
        "host1_template": "Host_{}_1",
        "host2_template": "Host_{}_2",
        "rule_name_template": "Rule_{}",
        "start_netobj_ip": "10.10.0.1",
        "rules_start_index": 1,
        "rules_end_index": 300,
        "logging": False
    }
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для автоматического создания правил в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -c config.json
Стандартная конфигурация:
{json.dumps(config, indent=4, ensure_ascii=False)}

{{}} - для вставки индекса в имя.
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('-c','--config', help='Путь до файла настроек.', type=str)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    if not args.config is None:
        if not os.path.exists(args.config):
            print('[\033[91;1m-\033[0m] Файл настроек отсутствует.')
            return

        with open(args.config, 'r') as f:
            config.update(json.load(f))

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    config_lock_data = api.config_lock_user()
    if config_lock_data['admin'] != None:
        print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        return

    api.set_config_lock()
    fork_data = api.fork_config()
    if not type(fork_data) is dict or 'uuid' not in fork_data.keys():
        print('[\033[91;1m-\033[0m] Ошибка блокировки конфига.')
        for msg in fork_data.get('__all__', []):
            print(f"\t{msg.get('message', '')}")
        api.free_config_lock()
        return
    config_uuid = fork_data['uuid']

    current_addr = ipaddress.IPv4Address(config['start_netobj_ip'])
    for i in range(config['rules_start_index'], config['rules_end_index']):
        name = config['host1_template'].format(i)
        src, current_addr = add_test_netobject(api, name, current_addr, config_uuid)

        name = config['host2_template'].format(i)
        dst, current_addr = add_test_netobject(api, name, current_addr, config_uuid)

        name = config['rule_name_template'].format(i)
        add_test_rule(api, name, src, dst, config['logging'], config_uuid)

        draw_progress(i, config['rules_start_index'], config['rules_end_index'], 40)

    api.commit_config(config_uuid)
    api.free_config_lock()
    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")

