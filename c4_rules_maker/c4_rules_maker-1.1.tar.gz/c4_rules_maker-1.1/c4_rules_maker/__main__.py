#!/usr/bin/env python3
import argparse
import os
import sys
import json
import ipaddress
import c4_lib

START_IP = "10.10.0.1"

def draw_progress(i, min_i, max_i, size):
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[92m{str_filler}{str_emptiness}\033[0m| \033[1m{i - min_i} / {max_i - min_i} - {percent}%\033[0m")
    sys.stdout.flush()
    if i == max_i:
        sys.stdout.write("\n")


def ip_inc(addr):
    ip = ip = addr.exploded
    while ip.endswith('.255') or ip.endswith('.0'):
        addr += 1
        ip = addr.exploded

    return addr


def host_of_set(host, set_num):
    return host + 256 * 256 * set_num + 256 * 256 * 256 * set_num

def result_check(result):
    if not type(result) is dict:
        return False

    if '__all__' in result.keys():
        msg_obj = result['__all__'][0]
        print(f"[\033[91;1m-\033[0m] {msg_obj['message']}")
        return False

    return True

def add_netobject(api, name, current_addr, config_uuid):
    """
    Добавляет сетевой объект в конфиг с определённым uuid, если объект существует, то только возвращет его uuid.

    Returns:
        Возвращает uuid  при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/netobject'
    ip = current_addr.exploded

    fields = {'name': name, 'description': '', 'subtype':'ip', 'ip': ip}
    netobj_data = api.post_to_endpoint(url, fields)

    # Если объект уже есть, возвращаем его uuid
    if 'name' in netobj_data.keys():
        objects = api.get_from_endpoint(url)
        for netobject in objects.get('data', []):
            if netobject.get('name') == name:
                return netobject.get('uuid')

    return netobj_data.get('uuid')


def add_service(api, name, proto, config_uuid, src=None, dst=None, icmp_type=None, icmp_code=None):
    """
    Добавляет сервис в конфиг с определённым uuid. Если сервис с таким именем существует, то возврашет uuid существующего.

    Args:
        name: имя.
        proto:
    Returns:
        Возвращает UUID при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/service'

    services = api.get_from_endpoint(url)
    if type(services) is dict:
        for service in services.get('data', []):
            if service.get('name') == name:
                return service.get('uuid')

    fields = {
        'name': name,
        'proto': proto
    }

    if proto in [6, 17]:
        fields['src'] = src
        fields['dst'] = dst

    if proto == 1:
        fields['icmp_type'] = icmp_type
        fields['icmp_code'] = icmp_code

    result = api.post_to_endpoint(url, fields)
    return result.get('uuid')


def add_fw_rule(api, name, src, dst, service, logging, action, config_uuid):
    """
    Создаёт правило фильтрации в конфиге с определённым uuid.

    Args:
        name: имя правила.
        src: список идентификаторов объектов-источников.
        dst: список идентификаторов объектов назначения.
        service: список сервисов.
        logging: логическое значение, определяющее включено ли логирование для правила.
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/fwrule'
    fields = {
        'type': 'fwrule',
        'name': name,
        'src': src,
        'dst': dst,
        'service': service,
        'rule_action': action,
        'logging': logging,
        'rule_position': {'last': True}
    }
    return api.post_to_endpoint(url, fields)


def add_nat_rule(api, name, src, dst, service, nat_type, config_uuid, description='', value=None, port_value=None):
    """
    Создаёт правило трансляции в конфиге с определённым uuid.

    Args:
        name: имя правила.
        description: описание.
        src: список идентификаторов объектов-источников.
        dst: список идентификаторов объектов назначения.
        service: список сервисов.
        value: сетевой объект транслированного пакета.
        port_value: сервис транслированного пакета.
        nat_type: тип NAT (original, masquerade, dynamic, dnat, static).
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/natrule'
    fields = {
        'name': name,
        'description': description,
        'src': src,
        'dst': dst,
        'service': service,
        'address_type': None,
        'value': value,
        'port_type': None,
        'port_value': port_value,
        'nat_type': nat_type,
        'type': 'natrule',
        'rule_position': {'last': True}
    }
    if not value is None:
        fields['address_type'] = 'netobject'

    if not port_value is None:
        fields['port_type'] = 'service'

    result = api.post_to_endpoint(url, fields)
    if api.result_check(result):
        return result['uuid']
    return None


def cli():
    config = {
        "fwrule": {
            "fwrule_create": False,
            "fwrule_logging": False,
            "fwrule_block": True
        },
        "natrule": {
            "original_create": False,
            "masquerade_create": False,
            "dynamic_create": False,
            "dnat_create": False,
            "static_create": False,
        },
        "service": {
            "tcp_service_include": False,
            "udp_service_include": False,
            "icmp_service_include": False,
            "nat_service_type": "tcp",
        },
        "common_settings": {
            "rules_start_index": 1,
            "rules_end_index": 100,
            "host_set_num": 1,
        }
    }
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для автоматического создания правил в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -c config.json
Стандартная конфигурация:
{json.dumps(config, indent=4, ensure_ascii=False)}
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('-c','--config', help='Путь до файла настроек.', type=str)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    if not args.config is None:
        if not os.path.exists(args.config):
            print('[\033[91;1m-\033[0m] Файл настроек отсутствует.')
            return

        with open(args.config, 'r') as f:
            config.update(json.load(f))

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        return

    fwrule_settings = config.get('fwrule', {})
    natrule_settings = config.get('natrule', {})
    service_settings = config.get('service', {})
    if not (fwrule_settings.get('fwrule_create', False) or \
            natrule_settings.get('original_create', False) or \
            natrule_settings.get('masquerade_create', False) or \
            natrule_settings.get('dynamic_create', False) or \
            natrule_settings.get('dnat_create', False) or \
            natrule_settings.get('static_create', False)):
        print('[\033[91;1m-\033[0m] Выключены все правила. Создавать нечего. Выход.')
        return

    nat_service_type = service_settings.get('nat_service_type', '')
    if nat_service_type is None or not type(nat_service_type) is str:
        nat_service_type = ''
    nat_service_type = nat_service_type.lower()

    if not nat_service_type in ['tcp', 'udp', '']:
        print('[\033[91;1m-\033[0m] Неподдерживаемый тип сервиса правил трансляции. Выход.')
        return

    start_idx = config.get('common_settings', {}).get('rules_start_index', 1)
    end_idx = config.get('common_settings', {}).get('rules_end_index', 1)
    end_idx += 1
    host_set_num = config.get('common_settings', {}).get('host_set_num', 1)

    if start_idx < 1 or end_idx < 1:
        print('[\033[91;1m-\033[0m] Индексы не могут быть меньше единицы. Выход.')
        return

    if start_idx >= 32767 or end_idx > 32767:
        print('[\033[91;1m-\033[0m] Индексы не могут быть больше или равны 32767. Выход.')
        return

    if start_idx > end_idx:
        print('[\033[91;1m-\033[0m] Начальный индекс не может быть больше конечного. Выход.')
        return

    if host_set_num < 1 or host_set_num > 25:
        print('[\033[91;1m-\033[0m] host_set_num не может быть меньше 1 или больше 25. Выход.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    config_lock_data = api.config_lock_user()
    if config_lock_data['admin'] != None:
        print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        return

    api.set_config_lock()
    fork_data = api.fork_config()
    if not type(fork_data) is dict or 'uuid' not in fork_data.keys():
        print('[\033[91;1m-\033[0m] Ошибка блокировки конфига.')
        for msg in fork_data.get('__all__', []):
            print(f"\t{msg.get('message', '')}")
        api.free_config_lock()
        return

    config_uuid = fork_data['uuid']

    # # # # # # # # # # #
    # FIREWALL
    # # # # # # # # # # #
    if fwrule_settings['fwrule_create'] == True:
        print("[*] Создание правил firewall.")
        current_addr = ipaddress.IPv4Address(START_IP)
        for i in range(start_idx, end_idx):
            src = []
            dst = []
            host2_ip = current_addr
            ip_inc(host2_ip)

            for j in range(0, host_set_num):
                name = f"Host_{j + 1}_{i}_1"
                src_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(current_addr, j),
                    config_uuid
                )
                if not src_uuid is None:
                    src.append(src_uuid)

                name = f"Host_{j + 1}_{i}_2"
                dst_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(host2_ip, j),
                    config_uuid
                )
                if not dst_uuid is None:
                    dst.append(dst_uuid)

            current_addr = ip_inc(host2_ip)

            services = []
            if service_settings.get('tcp_service_include', False):
                srvc_uuid = add_service(api, 'Service_TCP', 6, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)

            if service_settings.get('udp_service_include', False):
                srvc_uuid = add_service(api, 'Service_UDP', 17, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)

            if service_settings.get('icmp_service_include', False):
                srvc_uuid = add_service(api, 'Service_ICMP', 1, config_uuid)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)

            name = f"FW_Rule_{i}"
            action = 'block' if fwrule_settings.get('fwrule_block', True) else 'pass'
            result = add_fw_rule(
                api,
                name,
                src,
                dst,
                services,
                fwrule_settings.get('fwrule_logging'),
                action,
                config_uuid
            )
            if not result_check(result):
                return
            draw_progress(i, start_idx, end_idx, 40)

        print("[\033[92;1m+\033[0m] Создание правил firewall завершено.\n")


    # # # # # # # # # # #
    # NAT ORIGINAL
    # # # # # # # # # # #
    if natrule_settings['original_create'] == True:
        print('[*] Создание правил NAT с типом "Не транслировать".')
        current_addr = ipaddress.IPv4Address(START_IP)
        for i in range(start_idx, end_idx):
            src = []
            dst = []
            host2_ip = current_addr
            ip_inc(host2_ip)

            for j in range(0, host_set_num):
                name = f"Host_{j + 1}_{i}_1"
                src_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(current_addr, j),
                    config_uuid
                )
                if not src_uuid is None:
                    src.append(src_uuid)

                name = f"Host_{j + 1}_{i}_2"
                dst_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(host2_ip, j),
                    config_uuid
                )
                if not dst_uuid is None:
                    dst.append(dst_uuid)

            current_addr = ip_inc(host2_ip)

            services = []
            if service_settings.get('tcp_service_include', False) and nat_service_type == 'tcp':
                srvc_uuid = add_service(api, 'Service_TCP', 6, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)

            if service_settings.get('udp_service_include', False) and nat_service_type == 'udp':
                srvc_uuid = add_service(api, 'Service_UDP', 17, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)

            name = f"NAT_Rule_Original_{i}"
            result = add_nat_rule(api, name, src, dst, services, 'original', config_uuid)
            if not result_check(result):
                return
            draw_progress(i, start_idx, end_idx, 40)

        print('[\033[92;1m+\033[0m] Создание правил NAT с типом "Не транслировать" завершено.\n')


    # # # # # # # # # # #
    # NAT MASQUERADE
    # # # # # # # # # # #
    if natrule_settings['masquerade_create'] == True:
        print('[*] Создание правил NAT с типом "Скрыть".')
        current_addr = ipaddress.IPv4Address(START_IP)
        for i in range(start_idx, end_idx):
            src = []
            dst = []
            host2_ip = current_addr
            ip_inc(host2_ip)

            for j in range(0, host_set_num):
                name = f"Host_{j + 1}_{i}_1"
                src_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(current_addr, j),
                    config_uuid
                )
                if not src_uuid is None:
                    src.append(src_uuid)

                name = f"Host_{j + 1}_{i}_2"
                dst_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(host2_ip, j),
                    config_uuid
                )
                if not dst_uuid is None:
                    dst.append(dst_uuid)

            current_addr = ip_inc(host2_ip)

            services = []
            if service_settings.get('tcp_service_include', False) and nat_service_type == 'tcp':
                srvc_uuid = add_service(api, 'Service_TCP', 6, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)

            if service_settings.get('udp_service_include', False) and nat_service_type == 'udp':
                srvc_uuid = add_service(api, 'Service_UDP', 17, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)

            name = f"NAT_Rule_Masquerade_{i}"
            result = add_nat_rule(api, name, src, dst, services, 'masquerade', config_uuid)
            if not result_check(result):
                return
            draw_progress(i, start_idx, end_idx, 40)

        print('[\033[92;1m+\033[0m] Создание правил NAT с типом "Скрыть" завершено.\n')


    # # # # # # # # # # #
    # NAT DYNAMIC
    # # # # # # # # # # #
    if natrule_settings['dynamic_create'] == True:
        print('[*] Создание правил NAT с типом "Транслировать отправителя".')
        current_addr = ipaddress.IPv4Address(START_IP)
        for i in range(start_idx, end_idx):
            src = []
            dst = []
            host2_ip = current_addr
            ip_inc(host2_ip)

            for j in range(0, host_set_num):
                name = f"Host_{j + 1}_{i}_1"
                src_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(current_addr, j),
                    config_uuid
                )
                if not src_uuid is None:
                    src.append(src_uuid)

                name = f"Host_{j + 1}_{i}_2"
                dst_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(host2_ip, j),
                    config_uuid
                )
                if not dst_uuid is None:
                    dst.append(dst_uuid)

            current_addr = ip_inc(host2_ip)

            services = []
            trans_service = None
            if service_settings.get('tcp_service_include', False) and nat_service_type == 'tcp':
                srvc_uuid = add_service(api, 'Service_TCP', 6, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)
                srvc_uuid = add_service(api, 'Trans_Service_TCP_SrcPort', 6, config_uuid, src=12345)
                if not srvc_uuid is None:
                    trans_service = srvc_uuid

            if service_settings.get('udp_service_include', False) and nat_service_type == 'udp':
                srvc_uuid = add_service(api, 'Service_UDP', 17, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)
                srvc_uuid = add_service(api, 'Trans_Service_UDP_SrcPort', 17, config_uuid, src=12345)
                if not srvc_uuid is None:
                    trans_service = srvc_uuid

            src_uuid = add_netobject(
                api,
                'Trans_Host',
                ipaddress.IPv4Address('172.16.10.10'),
                config_uuid
            )

            name = f"NAT_Rule_Dynamic_{i}"
            result = add_nat_rule(api, name, src, dst, services, 'dynamic', config_uuid, value=src_uuid, port_value=trans_service)
            if not result_check(result):
                return
            draw_progress(i, start_idx, end_idx, 40)

        print('[\033[92;1m+\033[0m] Создание правил NAT с типом "Транслировать отправителя" завершено.\n')

    # # # # # # # # # # #
    # NAT DNAT
    # # # # # # # # # # #
    if natrule_settings['dnat_create'] == True:
        print('[*] Создание правил NAT с типом "Транслировать получателя".')
        current_addr = ipaddress.IPv4Address(START_IP)
        for i in range(start_idx, end_idx):
            src = []
            dst = []
            host2_ip = current_addr
            ip_inc(host2_ip)

            for j in range(0, host_set_num):
                name = f"Host_{j + 1}_{i}_1"
                src_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(current_addr, j),
                    config_uuid
                )
                if not src_uuid is None:
                    src.append(src_uuid)

                name = f"Host_{j + 1}_{i}_2"
                dst_uuid = add_netobject(
                    api,
                    name,
                    host_of_set(host2_ip, j),
                    config_uuid
                )
                if not dst_uuid is None:
                    dst.append(dst_uuid)

            current_addr = ip_inc(host2_ip)

            services = []
            trans_service = []
            if service_settings.get('tcp_service_include', False) and nat_service_type == 'tcp':
                srvc_uuid = add_service(api, 'Service_TCP', 6, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)
                srvc_uuid = add_service(api, 'Trans_Service_TCP_DstPort', 6, config_uuid, dst=12345)
                if not srvc_uuid is None:
                    trans_service = srvc_uuid

            if service_settings.get('udp_service_include', False) and nat_service_type == 'udp':
                srvc_uuid = add_service(api, 'Service_UDP', 17, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)
                srvc_uuid = add_service(api, 'Trans_Service_UDP_DstPort', 17, config_uuid, dst=12345)
                if not srvc_uuid is None:
                    trans_service = srvc_uuid

            src_uuid = add_netobject(
                api,
                'Trans_Host',
                ipaddress.IPv4Address('172.16.10.10'),
                config_uuid
            )

            name = f"NAT_Rule_DNat_{i}"
            result = add_nat_rule(api, name, src, dst, services, 'dnat', config_uuid, value=src_uuid, port_value=trans_service)
            if not result_check(result):
                return
            draw_progress(i, start_idx, end_idx, 40)

        print('[\033[92;1m+\033[0m] Создание правил NAT с типом "Транслировать получателя" завершено.\n')

    # # # # # # # # # # #
    # NAT STATIC
    # # # # # # # # # # #
    if natrule_settings['static_create'] == True:
        print('[*] Создание правил NAT с типом "Отобразить".')
        current_addr = ipaddress.IPv4Address(START_IP)
        for i in range(start_idx, end_idx):
            src = []
            dst = []
            host2_ip = current_addr
            ip_inc(host2_ip)

            j = 0
            name = f"Host_{j + 1}_{i}_1"
            src_uuid = add_netobject(
                api,
                name,
                host_of_set(current_addr, j),
                config_uuid
            )
            if not src_uuid is None:
                src.append(src_uuid)

            name = f"Host_{j + 1}_{i}_2"
            dst_uuid = add_netobject(
                api,
                name,
                host_of_set(host2_ip, j),
                config_uuid
            )
            if not dst_uuid is None:
                dst.append(dst_uuid)

            current_addr = ip_inc(host2_ip)

            services = []
            trans_service = []
            if service_settings.get('tcp_service_include', False) and nat_service_type == 'tcp':
                srvc_uuid = add_service(api, 'Service_TCP', 6, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)
                srvc_uuid = add_service(api, 'Trans_Service_TCP', 6, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    trans_service = srvc_uuid

            if service_settings.get('udp_service_include', False) and nat_service_type == 'udp':
                srvc_uuid = add_service(api, 'Service_UDP', 17, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    services.append(srvc_uuid)
                srvc_uuid = add_service(api, 'Trans_Service_UDP', 17, config_uuid, src=12345, dst=12345)
                if not srvc_uuid is None:
                    trans_service = srvc_uuid

            src_uuid = add_netobject(
                api,
                'Trans_Host',
                ipaddress.IPv4Address('172.16.10.10'),
                config_uuid
            )

            name = f"NAT_Rule_Static_{i}"
            result = add_nat_rule(api, name, src, dst, services, 'static', config_uuid, value=src_uuid, port_value=trans_service)
            if not result_check(result):
                return
            draw_progress(i, start_idx, end_idx, 40)

        print('[\033[92;1m+\033[0m] Создание правил NAT с типом "Отобразить" завершено.\n')

    api.commit_config(config_uuid)
    api.free_config_lock()
    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")

