from setuptools import setup
setup(name = 'c4_rules_maker',
    version = '1.0',
    py_modules = ['c4_rules_maker'],
    packages = ['c4_rules_maker'],
    install_requires = ['pycurl'],
    include_package_data = True,
    package_data = {'': ['openssl.cnf', 'gost.so']},
    entry_points = {
        'console_scripts': [
                'c4_rules_maker = c4_rules_maker:cli',
        ]
    }
)
