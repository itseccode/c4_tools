import argparse
import os
import sys
module_abspath = os.path.dirname(os.path.abspath(__file__))
os.environ['OPENSSL_CONF'] = f'{module_abspath}/openssl.cnf'
os.environ['OPENSSL_ENGINE_PATH'] = module_abspath

import pycurl
import certifi
from io import BytesIO
import json
import ipaddress

class ApiConnector:
    def __init__(self, ip, port, user, password):
        self._base_url_server = f'https://{ip}:{port}/api-v1-server'
        self._base_url_objects = f'https://{ip}:{port}/api-v1-objects'
        self._user = user
        self._password = password
        self._curl_obj = self.__get_curl_obj()

    def __exit__(self, exc_type, exc_value, traceback):
        self._curl_obj.close()

    def __parse_json(self, buffer):
        json_obj = {}
        try:
            json_obj = json.loads(buffer.getvalue().decode('utf-8'))
        except:
            print("Ошибка парсинга JSON")
        return json_obj

    def __get_curl_obj(self):
        curl_obj = pycurl.Curl()
        curl_obj.setopt(curl_obj.CONNECTTIMEOUT, 10)
        curl_obj.setopt(curl_obj.SSL_VERIFYPEER, False)
        curl_obj.setopt(curl_obj.SSL_VERIFYHOST, False)
        curl_obj.setopt(curl_obj.COOKIEFILE, "test.cookie")
        curl_obj.setopt(curl_obj.CAINFO, certifi.where())
        curl_obj.setopt(curl_obj.USERPWD, f"{self._user}:{self._password}")
        return curl_obj

    def config_lock_user(self, buffer = None):
        """
        Возвращает объект, описывающий блокировку конфига.

        Args:
            buffer: i/o буфер, в который будет записан ответ. По умолчанию None.
        Returns:
            Если буфер не задан, возвращает словарь. В противном случае - ничего.
        """
        external_buffer = False
        if buffer:
            _buffer = buffer
            external_buffer = True
        else:
            _buffer = BytesIO()

        c = self._curl_obj
        c.setopt(c.URL, f'{self._base_url_server}/config-lock-user')
        c.setopt(c.WRITEDATA, _buffer)
        c.setopt(c.POST, 0)
        c.perform()
        if external_buffer:
            return
        else:
            permissions_obj = self.__parse_json(_buffer)
            return permissions_obj

    def set_config_lock(self, buffer = None):
        """
        Устанавливает блокировку конфига.

        Args:
            buffer: i/o буфер, в который будет записан ответ. По умолчанию None.
        Returns:
            Если буфер не задан, возвращает словарь со статусом. В противном случае - ничего.
        """
        external_buffer = False
        if buffer:
            _buffer = buffer
            external_buffer = True
        else:
            _buffer = BytesIO()

        c = self._curl_obj
        #c.setopt(c.URL, f'{self._base_url_server}/force-config-lock')
        c.setopt(c.URL, f'{self._base_url_server}/acquire-config-lock')
        c.setopt(c.POSTFIELDS, '')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        if external_buffer:
            return
        else:
            permissions_obj = self.__parse_json(_buffer)
            return permissions_obj

    def add_test_netobject(self, name, ip, config_uuid, buffer = None):
        """
        Создаёт сетевой объект в конфиге с определённым uuid.

        Args:
            name: имя сетевого объекта.
            ip: адерс сетевого объекта.
            config_uuid: идентификатор конфига для добавления.
            buffer: i/o буфер, в который будет записан ответ. По умолчанию None.
        Returns:
            Если буфер не задан, возвращает словарь с uuid объекта. В противном случае - ничего.
        """
        external_buffer = False
        if buffer:
            _buffer = buffer
            external_buffer = True
        else:
            _buffer = BytesIO()

        c = self._curl_obj
        c.setopt(c.URL, f'{self._base_url_objects}/config/{config_uuid}/netobject')
        fields = {'name': name, 'description': '', 'subtype':'ip', 'ip': ip}
        c.setopt(c.POSTFIELDS, json.dumps(fields))
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        if external_buffer:
            return
        else:
            permissions_obj = self.__parse_json(_buffer)
            return permissions_obj

    def add_test_rule(self, name, src, dst, logging, config_uuid, buffer = None):
        """
        Создаёт правило фильтрации в конфиге с определённым uuid.

        Args:
            name: имя правила.
            src: список идентификаторов объектов-источников.
            dst: список идентификаторов объектов назначения.
            logging: логическое значение, определяющее включено ли логирование для правила.
            config_uuid: идентификатор конфига для добавления.
            buffer: i/o буфер, в который будет записан ответ. По умолчанию None.
        Returns:
            Если буфер не задан, возвращает словарь с uuid объекта. В противном случае - ничего.
        """
        external_buffer = False
        if buffer:
            _buffer = buffer
            external_buffer = True
        else:
            _buffer = BytesIO()

        c = self._curl_obj
        c.setopt(c.URL, f'{self._base_url_objects}/config/{config_uuid}/fwrule')
        fields = {
            'type': 'fwrule',
            'name': name,
            'src':src,
            'dst':dst,
            'rule_action':'block',
            'logging': logging,
            'rule_position': {'last': True}
        }
        c.setopt(c.POSTFIELDS, json.dumps(fields))
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        if external_buffer:
            return
        else:
            permissions_obj = self.__parse_json(_buffer)
            return permissions_obj


    def fork_active_config(self, buffer = None):
        """
        Создаёт форк активного конфига для изменений.

        Args:
            buffer: i/o буфер, в который будет записан ответ. По умолчанию None.
        Returns:
            Если буфер не задан, возвращает словарь с uuid форка. В противном случае - ничего.
        """
        external_buffer = False
        if buffer:
            _buffer = buffer
            external_buffer = True
        else:
            _buffer = BytesIO()

        c = self._curl_obj
        c.setopt(c.URL, f'{self._base_url_objects}/config')
        fields = {'name': 'new_config', 'subtype': 'adminedit', 'source': 'active'}
        c.setopt(c.POSTFIELDS, json.dumps(fields))
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        if external_buffer:
            return
        else:
            permissions_obj = self.__parse_json(_buffer)
            return permissions_obj

    def commit_config(self, uuid, buffer = None):
        """
        Запускает процесс слияния конфига с идентификатором uuid с активным.

        Args:
            uuid: идентификатор конфига для слияния с активным.
            buffer: i/o буфер, в который будет записан ответ. По умолчанию None.
        Returns:
            Если буфер не задан, возвращает словарь со статусом. В противном случае - ничего.
        """
        external_buffer = False
        if buffer:
            _buffer = buffer
            external_buffer = True
        else:
            _buffer = BytesIO()

        c = self._curl_obj
        c.setopt(c.URL, f'{self._base_url_server}/config/{uuid}/commit')
        c.setopt(c.POSTFIELDS, '')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        if external_buffer:
            return
        else:
            permissions_obj = self.__parse_json(_buffer)
            return permissions_obj

    def free_config_lock(self, buffer = None):
        """
        Снимает блокировку конфига.

        Args:
            buffer: i/o буфер, в который будет записан ответ. По умолчанию None.
        Returns:
            Если буфер не задан, возвращает словарь со статусом. В противном случае - ничего.
        """
        external_buffer = False
        if buffer:
            _buffer = buffer
            external_buffer = True
        else:
            _buffer = BytesIO()

        c = self._curl_obj
        c.setopt(c.URL, f'{self._base_url_server}/free-config-lock')
        c.setopt(c.POSTFIELDS, '')
        c.setopt(c.WRITEDATA, _buffer)
        c.perform()
        if external_buffer:
            return
        else:
            permissions_obj = self.__parse_json(_buffer)
            return permissions_obj

def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\npython {os.path.basename(sys.argv[0])}",
            description = 'Утилита для автоматического создания тестовых правил в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -q 5000
example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -q 3000 -l
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('-q', '--quantity', help='Количество создаваемых правил', default=3000, type=int)
    parser.add_argument('-l', '--logging', help='Включить логирование в правилах', action=argparse.BooleanOptionalAction)
    args = parser.parse_args()

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('Неверный формат реквизитов')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = ApiConnector(args.ip, args.port, user, password)

    config_lock_data = api.config_lock_user()
    if config_lock_data['admin'] != None:
        print('Конфигурация заблокирована из другого места. Выход.')
        return

    api.set_config_lock()
    fork_data = api.fork_active_config()
    if '__all__' in fork_data.keys():
        print(fork_data['__all__'][0]['message'])
        print('Выход.')
        api.free_config_lock()
        return
    config_uuid = fork_data['uuid']

    def __progress__(i, max_i, size):
        progress_percent = max_i / size
        progress = round(i / progress_percent)
        str_filler = "█" * progress
        str_emptiness = " " * (size - progress)
        sys.stdout.write(f"|\033[92m{str_filler}{str_emptiness}\033[0m| \033[1m{i} / {max_i}\033[0m")
        sys.stdout.flush()
        sys.stdout.write("\033[G")
        if i == max_i:
            sys.stdout.write("\n")

    current_addr = ipaddress.IPv4Address('10.10.0.0')
    for i in range(1, args.quantity + 1):
        name = f"Host_{i}_1"
        current_addr += 1
        while current_addr.exploded.endswith('.255') or current_addr.exploded.endswith('.0'):
            current_addr += 1
        netobj_data = api.add_test_netobject(name, current_addr.exploded, config_uuid)
        if 'name' in netobj_data.keys():
            print('Объект с таким имененм существует. Выход.')
            api.free_config_lock()
            return
        src = [netobj_data['uuid']]

        name = f"Host_{i}_2"
        current_addr += 1
        while current_addr.exploded.endswith('.255') or current_addr.exploded.endswith('.0'):
            current_addr += 1
        netobj_data = api.add_test_netobject(name, current_addr.exploded, config_uuid)
        if 'name' in netobj_data.keys():
            print('Объект с таким имененм существует. Выход.')
            api.free_config_lock()
            return
        dst = [netobj_data['uuid']]

        name = f"Rule_{i}"
        api.add_test_rule(name, src, dst, args.logging, config_uuid)

        __progress__(i, args.quantity, 40)


    api.commit_config(config_uuid)
    api.free_config_lock()
    sys.stdout.write("Выполнено\n")

