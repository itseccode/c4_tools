from setuptools import setup
name = 'aserv_c4_importer'
setup(name = name,
    version = '1.0',
    py_modules = [name],
    packages = [name],
    install_requires = ['c4_lib'],
    include_package_data = True,
    entry_points = {
        'console_scripts': [
                f'{name} = {name}.__main__:cli',
        ]
    }
)
