#!/usr/bin/env python3
import os
import sys
import json
import logging
import argparse
import c4_lib

log = logging.getLogger(__name__)

icmp_available = {
    3: [0, 1, 2, 3, 4, 5, 6,
        7, 8, 9, 10, 11, 12,
        13, 14, 15],
    5: [0, 1, 2, 3],
    6: [0],
    9: [0, 16],
    11: [0, 1],
    12: [0, 1, 2],
    40: [0, 1, 2, 3, 4, 5],
    42: [0],
    43: [0, 1, 2, 3, 4]
}

error = False

def icmp_validate(icmp_type, icmp_code):
    if icmp_type is None or icmp_code is None:
        return True

    if icmp_type in icmp_available.keys():
        if icmp_code in icmp_available[icmp_type]:
            return True

    return False


def get_netmask(netmask):
    return sum(bin(int(x)).count('1') for x in netmask.split('.'))


def draw_progress(i, min_i, max_i, size, error=False):
    color = 92 # green
    if error: color = 91 # red
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[{color}m{str_filler}{str_emptiness}\033[0m| {i - min_i} / {max_i - min_i} - \033[1m{percent}%\033[0m")
    sys.stdout.flush()
    if i == max_i:
        sys.stdout.write("\n")


def find_object(api, name, url):
    """Получаем объекты по url и ищем нужный"""
    users = api.get_from_endpoint(url)
    for user in users.get('data', []):
        if user.get('name') == name:
            return user
    return None


def result_check(fields, result):
    global error
    if not type(result) is dict:
        error = True
        return False

    if not 'uuid' in result.keys():
        error = True
        if 'message' in result.keys():
            log.error(' - '.join([fields.get('name', ''), result['message']]))
        else:
            for key in result.keys():
                msg_obj = result[key][0]
                log.error(' - '.join([f"{fields.get('name', '')}", f"{key}: {msg_obj['message']}"]))
        return False

    return True


def add_timeinterval(api, name, intervals, config_uuid, description=''):
    """
    Добавляет временной интервал в конфиг с определённым uuid, если объект существует, то только возвращет его uuid.

    Args:
        name: имя.
        intervals: интвервалы с временем начала и окончания в минутах: { 'day': 0, 'start': 600, 'finish': 1200 }.
        description: описание.
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f"{api.get_obj_url(config_uuid)}/timeinterval"

    result = find_object(api, name, url)
    if not result is None:
        return result.get('uuid')

    interval_obj = {
        "name": name,
        "description": description,
        "intervals": intervals,
        "is_limit_start_enabled": False,
        "is_limit_end_enabled": False
    }

    result = api.post_to_endpoint(url, interval_obj)
    if result_check(interval_obj, result):
        return result.get('uuid')
    return None


def add_netobject(api, name, current_addr, config_uuid, description=''):
    """
    Добавляет сетевой объект в конфиг с определённым uuid, если объект существует, то только возвращет его uuid.

    Args:
        name: имя.
        description: описание.
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/netobject'

    result = find_object(api, name, url)
    if not result is None:
        return result.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'ip': current_addr
    }

    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result.get('uuid')
    return None


def add_service(api, name, proto, config_uuid, description='', src=None, dst=None, icmp_type=None, icmp_code=None):
    """
    Добавляет сервис в конфиг с определённым uuid. Если сервис с таким именем существует, то возврашет uuid существующего.

    Args:
        name: имя.
        description: описание.
        proto: номер протокола.
        src: порт источника для сервисов с протоколами 6 (TCP) и 17 (UDP).
        dst: порт назначения для сервисов с протоколами 6 (TCP) и 17 (UDP).
        icmp_type: Тип ICMP (1).
        icmp_code: Код ICMP (1).
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает UUID при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/service'

    result = find_object(api, name, url)
    if not result is None:
        return result.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'proto': proto
    }

    if proto in [6, 17]:
        fields['src'] = src
        fields['dst'] = dst

    if proto == 1:
        fields['icmp_type'] = icmp_type
        fields['icmp_code'] = icmp_code

    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_usernetobject(api, name, is_enabled, login, organization, certs, config_uuid, description=''):
    """
    Добавляет пользователя в конфиг с определённым uuid, если объект существует, то только возвращет его uuid.

    Args:
        name: имя.
        description: описание.
        is_enabled: устанавливает активна ли учётная запись пользователя.
        login: логин пользователя.
        organization: организация пользователя.
        certs: список идентификаторов сертификатов пользователя.
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f"{api.get_obj_url(config_uuid)}/usernetobject"

    def find_user(name, url):
        view_url = f"{url}?view=full"
        users = api.get_from_endpoint(view_url)
        for user in users.get('data', []):
            if user.get('name') == name:
                return user
        return None

    user = find_user(name, url)
    if not user is None:
        certs_uuid = certs
        for cert in user.get('certs', []):
            certs_uuid.append(cert.get('uuid'))

        api.put_to_endpoint(f"{url}/{user.get('uuid')}", {'certs': certs_uuid})
        return user.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'is_enabled': is_enabled,
        'login': login,
        'organization': organization,
        'certs': certs
    }

    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result.get('uuid')
    return None


def add_fw_rule(api, name, src, dst, service, logging, action, config_uuid, description=''):
    """
    Создаёт правило фильтрации в конфиге с определённым uuid.

    Args:
        name: имя правила.
        description: описание.
        src: список идентификаторов объектов-источников.
        dst: список идентификаторов объектов назначения.
        service: список сервисов.
        rule_action: действие правила (pass, block, nocrypt)
        logging: логическое значение, определяющее включено ли логирование для правила.
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/fwrule'
    fields = {
        'name': name,
        'description': description,
        'src': src,
        'dst': dst,
        'service': service,
        'rule_action': action,
        'logging': logging,
        'type': 'fwrule',
        'rule_position': {'last': True}
    }
    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_cert(api, dbdata, role, config_uuid):
    """
    Добавляет сертификат.

    Args:
        dbdata: тело сертификата.
        role: тип сертификата: user, aserv, ca.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    dbdata = dbdata.replace('\\n', '\n').replace('\n\n', '\n')
    url = f'{api.get_obj_url(config_uuid)}/cert'

    objects = api.get_from_endpoint(url)
    for object in objects['data']:
        if object.get('dbdata') == dbdata:
            return object.get('uuid')

    cert_obj = {
        'role': role,
        'dbdata': dbdata,
        'ca': True if role == 'ca' else False
    }

    result = api.post_to_endpoint(url, cert_obj)
    if result_check({'name': dbdata}, result):
        return result.get('uuid')


def process_services(input_object, params_obj):
    proto_list = input_object.get('protos', [])
    proto = None
    if len(proto_list) > 0:
        proto = proto_list[0].get('proto')

    if proto in [33, 45, 46, 48, 50, 51, None]:
        return

    if proto == 0:
        proto = 4

    name = input_object.get('name', '')
    description = input_object.get('comment', '')
    if proto == 112:
        description = ' '.join([description, 'сервис VRRP'])

    icmp_type = input_object.get('type')
    icmp_code = input_object.get('code')
    if not icmp_validate(icmp_type, icmp_code):
        return

    src = input_object.get('src_port')
    dst = input_object.get('dst_port')

    if not src is None:
        port_list = src.split('-')
        if port_list[0] == port_list[1]:
            src = port_list[0]

    if not dst is None:
        port_list = dst.split('-')
        if port_list[0] == port_list[1]:
            dst = port_list[0]

    uuid = add_service(
        params_obj['api'],
        name,
        proto,
        params_obj['config_uuid'],
        description,
        src,
        dst,
        icmp_type,
        icmp_code
    )

    if not uuid is None:
        params_obj['uuids']['service'].append(
            {
                'id': input_object.get('id'),
                'uuid': uuid
            }
        )


def process_netobject(input_object, params_obj):
    mask = input_object.get('mask', '')
    ip = f"{input_object.get('addr', '')}/{get_netmask(mask)}"
    name = input_object.get('name', '')

    uuid = add_netobject(
        params_obj['api'],
        name=name,
        current_addr=ip,
        config_uuid=params_obj['config_uuid'],
        description=input_object.get('comment', '')
    )
    if not uuid is None:
        params_obj['uuids']['netobject'].append(
            {
                'id': input_object.get('id'),
                'uuid': uuid
            }
        )


def process_aserv(input_object, params_obj, ippools):
    api = params_obj['api']
    url = f"{params_obj['obj_url']}/aservcomponent/{params_obj['aserv_uuid']}"
    params = input_object.get('params', {})

    # сертификаты
    root_cert_uuids = []
    for cert in input_object.get('root_certs', []):
        uuid = add_cert(api, cert, 'ca', params_obj['config_uuid'])
        if not uuid is None:
            root_cert_uuids.append(uuid)

    srv_cert_uuids = []
    for cert in input_object.get('srv_certs', []):
        uuid = add_cert(api, cert, 'aserv', params_obj['config_uuid'])
        if not uuid is None:
            srv_cert_uuids.append(uuid)

    fields = {
        'dns': input_object.get('dns', []),
        'non_active_time': params.get('alive_timeout', 60),
        'use_crl': True if params.get('use_crl', 0) > 0 else False,
        'isolate_users': not input_object.get('is_p2p_allowed', False),
        'root_certs': root_cert_uuids,
        'srv_certs': srv_cert_uuids,
        'ippools': ippools
    }
    result = api.put_to_endpoint(url, fields)
    result_check(input_object, result)


def process_usernetobject(input_object, params_obj):
    api = params_obj['api']
    name = input_object.get('name', '')

    # сертификат
    cert_uuids = []
    for cert in input_object.get('certs', []):
        uuid = add_cert(api, cert, 'user', params_obj['config_uuid'])
        if not uuid is None:
            cert_uuids.append(uuid)

    user_uuid = add_usernetobject(
        api,
        name=name,
        description = input_object.get('comment', ''),
        is_enabled = input_object.get('status', 0) > 0,
        login=name,
        organization = input_object.get('organization', ''),
        certs=cert_uuids,
        config_uuid=params_obj['config_uuid']
    )

    if not user_uuid is None:
        # заполнение полей для связи пользователей с aservpool
        if not name in params_obj['users_in_pool']:
            params_obj['users'].append(user_uuid)
            if input_object.get('has_static_ip', 0) > 0:
                params_obj['users_ip'].append({'uuid': user_uuid, 'ip': input_object['static_addr']})

        params_obj['uuids']['usernetobject'].append(
            {
                'id': input_object.get('id'),
                'uuid': user_uuid,
                'fw_rules': input_object.get('rules', []),
                'name': name
            }
        )


def process_fw_rule(fw_rule, user_uuid, params_obj, netobjects):
    if fw_rule.get('dst') == '':
        return

    api = params_obj['api']

    def uuid_by_id(section, object_type):
        src_uuids = []
        netobjects = params_obj['uuids'].get(object_type, [])
        rule_netobject_name = fw_rule.get(section, [])
        for imported_netobject in netobjects:
            if imported_netobject['id'] == rule_netobject_name:
                src_uuids.append(imported_netobject['uuid'])
                break
        return src_uuids

    name = fw_rule.get('name', '')
    description = fw_rule.get('comment', '')
    dst_uuids = uuid_by_id('dst', 'netobject')
    netobjects.extend(dst_uuids)
    src_uuids = []
    if not fw_rule.get('src') == '':
        src_uuids = uuid_by_id('src', 'netobject')

    service_uuids = []
    services = params_obj['uuids'].get('service', [])
    for rule_service_id in fw_rule.get('services', []):
        for service in services:
            if service['id'] == rule_service_id:
                service_uuids.append(service['uuid'])
                break

    add_fw_rule(
        api,
        name=name,
        description=description,
        action= 'pass' if fw_rule.get('action', 'block') == 'pass' else 'block',
        logging=fw_rule.get('logging', False),
        src= user_uuid if src_uuids == [] else src_uuids,
        dst= dst_uuids,
        service=service_uuids,
        config_uuid=params_obj['config_uuid']
    )


def process_access_rule(policy, netobjects, user, params_obj):
    api = params_obj['api']
    name = f"{user['name']}_access"

    interval = None
    for interval in policy.get('time_restrictions', []):
        intervals = []
        start = interval.get('start', '00:00:00').split(':')
        start = int(start[0]) * 60 + int(start[1])
        end = interval.get('end', '00:00:00').split(':')
        end = int(end[0]) * 60 + int(end[1])
        for day in interval.get('weekdays', []):
            obj = {
                'day': day,
                "start": start,
                "finish": end
            }
            intervals.append(obj)

        interval = add_timeinterval(
            api,
            f"{user['name']}_interval",
            intervals,
            params_obj['config_uuid'],
            f"Временной интервал для правила {name}"
        )
        break

    fields = {
        'name': name,
        'description': '',
        'auth_method': 'cert',
        'connection_control': policy.get('connection_control', 'no_control'),
        'is_multiconnect': policy.get('is_multiconnect', False),
        'order': policy.get('position'),
        'users': [user['uuid']],
        'netobjects': netobjects,
        'time_restriction': interval,
        'cgws': [params_obj['cgw_uuid']],
        'rule_position': {'last': True}
    }
    url = f"{params_obj['obj_url']}/aservpolicy"
    result = api.post_to_endpoint(url, fields)
    result_check(fields, result)


# Порядок важен!
sections_processing = [
    {
        'section': 'Services',
        'name': 'сервисы',
        'function': process_services
    },
    {
        'section': 'subnet_info',
        'name': 'сетевые объекты',
        'function': process_netobject
    },
    {
        'section': 'Objects',
        'name': 'пользователи',
        'function': process_usernetobject
    }
]


def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для импорта конфигурации СД Континент 3 в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -c config.json
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP ЦУС К4.', type=str, required=True)
    parser.add_argument('--port', help='Порт ЦУС К4.', default='444', type=str)
    parser.add_argument('-c','--config', help='Путь до файла с конфигурацией СД Континент 3.', type=str)
    parser.add_argument('-n','--name_aserv', help='Имя СД Континент 4, в который будет перенесена конфигурация.', type=str)
    parser.add_argument('-l', help='Вывести список доступных СД Континент 4.', action=argparse.BooleanOptionalAction)
    parser.add_argument('--log', help='Имя файла логирования', default=f"{os.path.basename(sys.argv[0])}.log", type=str)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    logging.basicConfig(encoding='utf-8', level=logging.INFO, filename=args.log,
    format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    # Соединение с API
    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    # Вывод списка доступных СД
    if args.l:
        print("Доступные СД:")
        url = f"{api.get_obj_url('active')}/cgw"
        cgws = api.get_from_endpoint(url)
        for cgw in cgws.get('data', []):
            platform = cgw.get('platform', {})
            if 'aserv' in platform.get('capabilities', []):
                print(f"\t{cgw.get('name')}")
        return

    if args.name_aserv is None or args.name_aserv == '':
        print('[\033[91;1m-\033[0m] Необходимо указать имя СД.')
        return

    # Загрузка конфигурации К3
    if args.config is None or not os.path.exists(args.config):
        print('[\033[91;1m-\033[0m] Файл настроек отсутствует.')
        return

    input_data = {}
    with open(args.config, 'r') as f:
        input_data = json.load(f)

    # Блокировка конфигурации в К4
    config_lock_data = api.config_lock_user()
    if config_lock_data['admin'] != None:
        print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        return

    api.set_config_lock()
    fork_data = api.fork_config()
    if not type(fork_data) is dict or 'uuid' not in fork_data.keys():
        print('[\033[91;1m-\033[0m] Ошибка блокировки конфига.')
        for msg in fork_data.get('__all__', []):
            print(f"\t{msg.get('message', '')}")
        api.free_config_lock()
        return

    # Поиск aservcomponent по имени cgw
    aserv_uuid = ''
    cgw_uuid = ''
    aserv_url = f"{api.get_obj_url('active')}/aservcomponent?view=full"
    aservs = api.get_from_endpoint(aserv_url)
    for aserv in aservs.get('data', []):
        cgw = aserv.get('owner', {})
        if cgw.get('name', '') == args.name_aserv:
            aserv_uuid = aserv.get('uuid', '')
            cgw_uuid = cgw.get('uuid', '')
            break

    aserv_obj = input_data.get('aserv', {})
    config_uuid = fork_data['uuid']
    obj_url = api.get_obj_url(config_uuid)

    ippools = []
    result = api.get_from_endpoint(f"{obj_url}/aservpool")
    for pool in result.get('data', []):
        ippools.append(pool.get('uuid'))

    ippool_uuid = None
    ippool_addr = None
    if 'ippool' in aserv_obj.keys():
        for pool in aserv_obj['ippool']:
            result = api.post_to_endpoint(f"{obj_url}/aservpool", pool)
            result_check(aserv_obj, result)
            if 'uuid' in result:
                ippool_uuid = result['uuid']
                ippool_addr = pool['ip']
                ippools.append(result['uuid'])

    params_obj = {
        'api': api,
        'config_uuid': config_uuid,
        'obj_url': obj_url,
        'aserv_uuid': aserv_uuid,
        'cgw_uuid': cgw_uuid,
        'uuids': {
            'netobject': [],
            'service': [],
            'usernetobject': []
        },
        'users': [],
        'users_ip': [],
        'users_in_pool': []
    }

    print(f"[*] Импорт секции \"настройки СД\".")
    process_aserv(aserv_obj, params_obj, ippools)
    print(f"[\033[92;1m+\033[0m] Импорт секции \"настройки СД\" завершён.")

    # получение имён пользоваталей, уже находяшихся в ippool
    pools = api.get_from_endpoint(f"{obj_url}/aservpool?view=full")
    for pool in pools.get('data', []):
        for user in pool.get('users', []):
            params_obj['users_in_pool'].append(user.get('name'))

        for user in pool.get('users_ip', []):
            params_obj['users_in_pool'].append(user.get('name'))


    for section in sections_processing:
        print(f"[*] Импорт секции \"{section['name']}\".")
        section_name = section['section']
        input_section = input_data.get(section_name)
        if input_section is None: input_section = []

        max = len(input_section)
        i = 0
        for input_object in input_section:
            draw_progress(i, 0, max, 40, error)
            section['function'](input_object, params_obj)
            i += 1

        print(f"[\033[92;1m+\033[0m] Импорт секции \"{section['name']}\" завершён.")

    result = api.put_to_endpoint(f"{obj_url}/aservpool/{ippool_uuid}",
        {
            'users': params_obj['users'],
            'users_ip': params_obj['users_ip'],
            'ip': ippool_addr
        }
    )
    result_check({'name': 'aservpool'}, result)

    print(f"[*] Импорт секции \"правила\".")
    i = 0
    i_max = len(params_obj['uuids']['usernetobject'])
    for user in params_obj['uuids']['usernetobject']:
        draw_progress(i, 0, i_max, 40, error)
        # извлечение правил, связанных с пользователем
        fwrules = []
        aservpolicys = []

        Rules = input_data.get('Rules', [])
        if Rules is None: Rules = []
        for rule in Rules:
            if rule.get('id') in user.get('fw_rules', []):
                fwrules.append(rule)

        aserv_policy = input_data.get('aserv_policy', [])
        if aserv_policy is None: aserv_policy = []
        for rule in aserv_policy:
            if user.get('id') in rule.get('users', []):
                aservpolicys.append(rule)

        # создание правил фильтрации и доступа
        netobjects = []
        for fw_rule in fwrules:
            process_fw_rule(fw_rule, [user.get('uuid')], params_obj, netobjects)

        for policy in aservpolicys:
            process_access_rule(policy, netobjects, user, params_obj)

        i += 1
    print(f"[\033[92;1m+\033[0m] Импорт секции \"правила\" завершён.")

    api.commit_config(params_obj['config_uuid'])
    api.free_config_lock()
    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")
    print(f"Записан лог: {args.log}")