#!/usr/bin/env python3
import os
import sys
import json
import socket
import logging
import datetime
import argparse
import c4_lib

log = logging.getLogger(__name__)

def draw_progress(i, min_i, max_i, size, error=False):
    color = 92 # green
    if error: color = 91 # red
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[{color}m{str_filler}{str_emptiness}\033[0m| {i - min_i} / {max_i - min_i} - \033[1m{percent}%\033[0m")
    sys.stdout.flush()
    if i == max_i:
        sys.stdout.write("\n")


def valid_ip(address):
    try:
        socket.inet_aton(address)
        return True
    except:
        return False


def result_check(fields, result):
    """
    Проверяет возвращаемые данные и записыват ошибку в лог, если она есть

    :Parameters:
        fields
            dict {'name': 'имя объекта'...}.
        result
            Возвращаемое значение от C4 API.

    :return:
        Возвращает False, если от API вернулась ошибка.
    """
    if not type(result) == dict:
        return False

    if not 'uuid' in result.keys():
        if 'message' in result.keys():
            log.error(' - '.join([fields.get('name', ''), result['message']]))
        else:
            for key in result.keys():
                msg_obj = result[key]
                if len(result[key]) > 0:
                    msg_obj = result[key][0]

                log.error(' - '.join([f"{fields.get('name', '')}", f"{key}: {msg_obj.get('message')}"]))

        return False

    return True


def add_netobject(api, name, current_addr, config_uuid):
    """
    Добавляет сетевой объект в конфиг с определённым uuid, если объект существует, то только возвращет его uuid.

    :Parameters:
        name
            Имя объекта
        current_addr
            ip адрес

    :return:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/netobject'

    fields = {'name': name, 'description': '', 'subtype': 'ip', 'ip': current_addr}
    netobj_data = api.post_to_endpoint(url, fields)

    # Если объект уже есть, возвращаем его uuid
    uuid = {}
    if 'name' in netobj_data.keys():
        objects = api.get_from_endpoint(url)
        for netobject in objects['data']:
            if netobject['name'] == name:
                uuid = netobject['uuid']
    else:
        uuid = netobj_data['uuid']
    return uuid


def add_netobject_group(api, name, config_uuid):
    """
    Добавляет группу сетевых объектов.

    :Parameters:
        name
            имя объекта

    :return:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group'

    groups = api.get_from_endpoint(url)
    if type(groups) == dict:
        for group in groups.get('data', []):
            if group.get('name') == name:
                return group.get('uuid')

    fields = {'name': name, 'description': '', 'subtype': 'netobject'}
    obj_data = api.post_to_endpoint(url, fields)

    if result_check(fields, obj_data):
        return obj_data['uuid']
    return None


def add_appfilter(api, name, url_regex, urlpath_regexes, filter_type, config_uuid):
    """
    Добавляет web фильтр.

    :Parameters:
        name
            Имя объекта.
        url_regex
            Регулярное выражение url пути.
        urlpath_regexes
            Список регулярных выражений хостов.
        filter_type
            Протокол: http, https, ftp.

    :return:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/appfilter'

    appfilters = api.get_from_endpoint(url)
    if type(appfilters) == dict:
        for appfilter in appfilters.get('data', []):
            if appfilter.get('name') == name:
                return appfilter.get('uuid')

    fields = {
        'name': '',
        'description': name,
        'url_regex': url_regex,
        'filter_type': filter_type,
        'urlpath_regexes': urlpath_regexes,
        'methods': [],
        'mime_types': []
    }
    obj_data = api.post_to_endpoint(url, fields)

    if result_check( {'name': name}, obj_data):
        return obj_data['uuid']
    return None


def add_appfilter_group(api, name, filter_type, config_uuid, description=''):
    """
    Добавляет группу web фильтров.

    :Parameters:
        name
            Имя объекта.
        filter_type
            Протокол: http, https, ftp.
        description
            Описание.

    :return:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group'

    groups = api.get_from_endpoint(url)
    if type(groups) == dict:
        for group in groups.get('data', []):
            if group.get('name') == name:
                return group.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'subtype': 'appfilter',
        'params': {
            'filter_type': filter_type,
            'type': 'appfilter',
            'tag': 'custom_url'
        }
    }
    obj_data = api.post_to_endpoint(url, fields)

    if result_check(fields, obj_data):
        return obj_data['uuid']
    return None


def add_dnsrecord(api, name, idn, config_uuid, description=''):
    """
    Добавляет dns запись.

    :Parameters:
        name
            Имя объекта.
        idn
            Доменное имя.
        description
            Описание.

    :return:
        Возвращает uuid при успешном добавлении.
    """
    if valid_ip(idn):
        return None

    url = f'{api.get_obj_url(config_uuid)}/dnsrecord'

    records = api.get_from_endpoint(url)
    if type(records) == dict:
        for record in records.get('data', []):
            if record.get('name') == name:
                return record.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'idn': idn
    }
    obj_data = api.post_to_endpoint(url, fields)

    if result_check(fields, obj_data):
        return obj_data['uuid']
    return None


def add_dnsrecord_group(api, name, config_uuid, description=''):
    """
    Добавляет группу DNS записей.

    :Parameters:
        name
            Имя объекта.
        description
            Описание.

    :return:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group'

    groups = api.get_from_endpoint(url)
    if type(groups) == dict:
        for group in groups.get('data', []):
            if group.get('name') == name:
                return group.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'subtype': 'dnsrecord'
    }
    obj_data = api.post_to_endpoint(url, fields)

    if result_check(fields, obj_data):
        return obj_data['uuid']
    return None


def add_to_group(api, uuid, members, config_uuid):
    """
    Добавляет объекты в группу.

    :Parameters:
        uuid
            Идентификатор группы.
        members
            Список идентификаторов объектов.

    :return:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group/{uuid}'
    result_check(
        {'name': ''},
        api.put_to_endpoint(url, {'members': members})
    )


def add_fw_rule(api, config_uuid, name, action='block', enabled=False, src=[], dst=[], service=[], applications=[], app_profile=None, logging=False, description='', first_position=False):
    """
    Создаёт правило фильтрации в конфиге с определённым uuid.

    :Parameters:
        api
            Объект c4_lib
        config_uuid
            Идентификатор конфига для добавления.
        name : str
            Имя правила.
        action : str
            Действие правила (pass, block, nocrypt)
        enabled : bool
            Определяет, активно ли правило
        src : list
            Список идентификаторов объектов-источников.
        dst : list
            Список идентификаторов объектов назначения.
        service : list
            Список сервисов.
        applications
            Протокол/приложение.
        app_profile
            uuid профиля
        logging : bool
            Логическое значение, определяющее включено ли логирование для правила.
        description : str
            Описание.
        first_position : str
            Позиция создаваемого правила (first - первое, last - последнее).

    :return:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/fwrule'
    fields = {
        'name': name,
        'is_enabled': enabled,
        'description': description,
        'src': src,
        'dst': dst,
        'service': service,
        'applications': applications,
        'rule_action': action,
        'logging': logging,
        'app_profile': app_profile,
        'type': 'fwrule',
        'rule_position': 'first' if first_position else 'last'
    }
    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_app_profile(api, config_uuid, name, description='', filter_type='', redirect_address='', accept_groups=[], deny_groups=[], redirect_groups=[], whitelist='', blacklist=''):
    """
    Создаёт профиль web/ftp фильтрации.

    :Parameters:
        api
            Объект c4_lib
        config_uuid
            Идентификатор конфига для добавления
        name
            Имя профиля
        description
            Описание
        filter_type
            Схема (http, https, ftp)
        redirect_address
            Адрес перенаправления.
        accept_groups
            Разрешённые группы
        deny_groups
            Запрещённые группы
        redirect_groups
            Группы для перенаправления
        whitelist
            Белый список
        blacklist
            Чёрный список

    :return:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/appprofile'
    fields = {
        'name': name,
        'description': description,
        'filter_type': filter_type,
        'redirect_address': redirect_address,
        'accept_groups': accept_groups,
        'deny_groups': deny_groups,
        'redirect_groups': redirect_groups,
        'whitelist': whitelist,
        'blacklist': blacklist
    }
    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_ecap_service(api, config_uuid, name, description=''):
    """
    Создаёт сервис для отправки данных на проверку внутренним антивирусом.

    :Parameters:
        api
            Объект c4_lib
        config_uuid
            Идентификатор конфига для добавления.
        name
            Имя сервиса.
        description
            Описание.

    :return:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/ecap'
    fields = {
        'name': name,
        'description': description,
        'maxsize': 10240,
        'bypass': False,
        'reqmod_on': False,
        'respmod_on': True,
        'content': [],
        'regex': '',
        'mode': 'userfs',
        'action_pass': True
    }
    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_schedule(api, config_uuid):
    """
    Создаёт расписание для установки обновления.
    Единоразово, через 5 минут.

    :Parameters:
        api
            Объект c4_lib
        config_uuid
            Идентификатор конфига для добавления.

    :return:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/schedule'
    now = datetime.datetime.utcnow()
    now += datetime.timedelta(minutes=5)
    fields = {
        'subtype': 'one_time',
        'period': 24,
        'start': now.strftime('%FT%T')
    }
    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_installupdaterule(api, config_uuid, name, schedule='', install_on=[], subtype='UserFS', action='install_on_cgw'):
    """
    Создаёт правило установки обновлений пользовательских хэшей.

    :Parameters:
        api
            Объект c4_lib
        config_uuid
            Идентификатор конфига для добавления
        name
            Имя
        schedule
            UUID объекта расписания
        install_on
            Список УБ для утсановки
        subtype
            Тип обновлений
        action
            Действие (install_on_cgw, ...)

    :return:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/installupdaterule'
    fields = {
        'name': name,
        'is_enabled': True,
        'schedule': schedule,
        'install_on': install_on,
        'subtype': subtype,
        'action': action
    }
    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def find_object(objects, name):
    for obj in objects.get('data', []):
        obj_name = obj.get('name')
        if obj_name == name:
            return obj.get('uuid')


def remove_objects(api, url, type, message, prefix='IoC: '):
    objs = api.get_from_endpoint(f"{url}/{type}")
    for obj in objs.get('data', []):
        obj_name = obj.get('name')
        if not obj_name.startswith(prefix):
            continue

        log.info(f"{message}{obj_name}")
        print(f"{message}{obj_name}")
        members = obj.get('members', [])
        max_i = len(members)
        i = 0
        for member in members:
            draw_progress(i, 0, max_i, 40, False)
            i += 1
            api.delete_obj(f"{url}/{member.get('type')}", member.get('uuid'))

        api.delete_obj(f"{url}/{type}", obj.get('uuid'))


def print_cgws(api):
    """
    Печатает список УБ.
    """
    cgws = api.get_cgw_obj()
    for cgw in cgws['data']:
        print(f"Name: {cgw.get('name')}, hwserial: {cgw.get('hwserial')}, uuid: {cgw.get('uuid')}")


def get_cgws_uuid_by_name(api, names):
    """
    Возвращает список uuid по списку имён УБ.
    """
    if names == None:
        return []

    if type(names) == str:
        names = [names]

    out_list = []
    cgws = api.get_cgw_obj()
    for cgw in cgws['data']:
        if cgw.get('name') in names:
            out_list.append(cgw.get('uuid'))

    return out_list


def create_ip_group_rules(api, config_uuid, ip_group, rules_enabled, first_position):
    error = False
    if not ip_group == None:
        rule_uuid = add_fw_rule(
            api=api,
            config_uuid=config_uuid,
            name=f"IoC: Malicious Hosts Block - Source",
            enabled=rules_enabled,
            src=[ip_group],
            action='block',
            first_position=first_position
        )

        if rule_uuid == None:
            error = True

        rule_uuid = add_fw_rule(
            api=api,
            config_uuid=config_uuid,
            name=f"IoC: Malicious Hosts Block - Destination",
            enabled=rules_enabled,
            dst=[ip_group],
            action='block',
            first_position=first_position
        )

        if rule_uuid == None:
            error = True

    return error


def create_domains_group_rules(api, config_uuid, domains_group, rules_enabled, first_position):
    error = False
    if not domains_group == None:
        rule_uuid = add_fw_rule(
            api=api,
            config_uuid=config_uuid,
            name=f"IoC: Malicious FQDN Block - Source",
            enabled=rules_enabled,
            src=[domains_group],
            action='block',
            first_position=first_position
        )

        if rule_uuid == None:
            error = True

        rule_uuid = add_fw_rule(
            api=api,
            config_uuid=config_uuid,
            name=f"IoC: Malicious FQDN BLock - Destination",
            enabled=rules_enabled,
            dst=[domains_group],
            action='block',
            first_position=first_position
        )

        if rule_uuid == None:
            error = True

    return error


def create_hash_url_rules(api, config_uuid, services, profile_uuid, rules_enabled, first_position):
    error = False
    if not None in services and profile_uuid != None:
        rule_uuid = add_fw_rule(
            api=api,
            config_uuid=config_uuid,
            name=f"IoC: Malicious URL & Hashes Block",
            enabled=rules_enabled,
            app_profile=profile_uuid,
            action='pass',
            service=services,
            first_position=first_position
        )

        if rule_uuid == None:
            error = True

    return error


def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для импорта индикаторов компрометации в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -c ioc.json
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('--log', help='Имя файла логирования', default=f"{os.path.basename(sys.argv[0])}.log", type=str)
    parser.add_argument('-i','--ioc', help='Путь до файла с индикаторами компрометации.', type=str)
    parser.add_argument('--cgw_list', nargs='+', help='Список имён УБ для установки хэшей.', default=[])
    if sys.version_info.major == 3 and sys.version_info.minor < 9:
        parser.add_argument('--create_rules', help='Создать правила для блокировки соединений с IoC. По умолчанию выключено.', action='store_true')
        parser.set_defaults(create_rules=False)
        parser.add_argument('--print_cgws', help='Вывести список УБ и завершить работу.', action=argparse.BooleanOptionalAction)
        parser.set_defaults(print_cgws=False)
        parser.add_argument('--enable_rules', help='Создавать сразу активированные правила.', action=argparse.BooleanOptionalAction)
        parser.set_defaults(enable_rules=False)
        parser.add_argument('--top_rules', help='Создавать правила сверху списка.', action=argparse.BooleanOptionalAction)
        parser.set_defaults(top_rules=False)
    else:
        parser.add_argument('--create_rules', help='Создать правила для блокировки соединений с IoC. По умолчанию выключено.', action=argparse.BooleanOptionalAction)
        parser.add_argument('--print_cgws', help='Вывести список УБ и завершить работу.', action=argparse.BooleanOptionalAction)
        parser.add_argument('--enable_rules', help='Создавать сразу активированные правила.', action=argparse.BooleanOptionalAction)
        parser.add_argument('--top_rules', help='Создавать правила сверху списка.', action=argparse.BooleanOptionalAction)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    if sys.version_info.major == 3 and sys.version_info.minor < 9:
        logging.basicConfig(level=logging.INFO, filename=args.log,
        format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    else:
        logging.basicConfig(encoding='utf-8', level=logging.INFO, filename=args.log,
        format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        log.error('Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    if args.print_cgws:
        print_cgws(api)
        return

    error = False
    ioc_data = {}

    if args.ioc == None or not os.path.exists(args.ioc):
        print('[\033[91;1m-\033[0m] Файл настроек отсутствует.')
        log.error('Файл настроек отсутствует.')
        return

    with open(args.ioc, 'r') as f:
        ioc_data = json.load(f)

    urls = []
    ips = []
    domains = []
    hashes = []
    for i in ioc_data:
        if i.get('type') == 'ip':
            ips.append(i)

        if i.get('type') == 'url':
            urls.append(i)

        if i.get('type') == 'domain':
            domains.append(i)

        if i.get('type') == 'hash':
            hashes.append(i)

    del ioc_data

    config_lock_data = api.config_lock_user()
    if config_lock_data['admin'] != None:
        print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        log.error('Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        return

    api.set_config_lock()
    fork_data = api.fork_config()
    if not type(fork_data) == dict or 'uuid' not in fork_data.keys():
        print('[\033[91;1m-\033[0m] Ошибка блокировки конфига.')
        log.error('Ошибка блокировки конфига.')
        for msg in fork_data.get('__all__', []):
            print(f"\t{msg.get('message', '')}")
            log.error(msg.get('message', ''))
        api.free_config_lock()
        return

    config_uuid = fork_data['uuid']

    print("[*] Очистка устаревших данных.")
    log.info("Очистка устаревших данных.")

    obj_url = api.get_obj_url(config_uuid)
    remove_objects(api, obj_url, "fwrule", 'Удаление правила: ')
    remove_objects(api, obj_url, "appprofile", 'Удаление профиля: ', 'IoC_K_')
    remove_objects(api, obj_url, "group", 'Удаление группы: ', 'IoC_K_')
    remove_objects(api, obj_url ,"ecap", 'Удаление ecap сервиса: ', 'IoC_K_')

    objs = api.get_from_endpoint(f"{obj_url}/installupdaterule")
    for obj in objs.get('data', []):
        obj_name = obj.get('name')
        if not obj_name.startswith('IoC: '):
            continue

        log.info(f"Удаление профиля обновления базы хэшей: {obj_name}")
        api.delete_obj(f"{obj_url}/installupdaterule", obj.get('uuid'))
        schedule_uuid = None
        schedule = obj.get('schedule')
        if type(schedule) == dict:
            schedule_uuid = schedule.get('uuid')
        else:
            schedule_uuid = schedule

        api.delete_obj(f"{obj_url}/schedule", schedule_uuid)

    print('[\033[92;1m+\033[0m] Очистка завершена.\n')
    log.info("Очистка завершена.")

    ip_group = None
    http_group = None
    https_group = None
    domains_group = None

    len_ips = len(ips)
    if len_ips > 0:
        print(f"[*] Импорт {len_ips} вредоносных хостов.")
        log.info(f"Импорт {len_ips} вредоносных хостов.")
        i = 0
        malicious_hosts_uuids = []
        for host in ips:
            draw_progress(i, 0, len_ips, 40, error)
            i += 1
            uuid = add_netobject(api, f"IoC_K_{host['value']}", host['value'], config_uuid)
            if not uuid == None:
                malicious_hosts_uuids.append(uuid)
            else:
                error = True

        ip_group = add_netobject_group(api, 'IoC_K_IP_Group', config_uuid)
        if not ip_group == None:
            add_to_group(api, ip_group, malicious_hosts_uuids, config_uuid)
        else:
            error = True

        print('[\033[92;1m+\033[0m] Импорт вредоносных хостов завершён.\n')
        log.info(f"Импорт вредоносных хостов завершён.")

    len_urls = len(urls)
    if len_urls > 0:
        print(f"[*] Импорт {len_urls} вредоносных URL.")
        log.info(f"Импорт {len_urls} вредоносных URL.")
        i = 0
        malicious_http_uuids = []
        malicious_https_uuids = []
        for url in urls:
            draw_progress(i, 0, len_urls, 40, error)
            i += 1
            filter_type = url['value'].split('://')[0]
            filter_type = filter_type.lower()
            if not filter_type in ['http', 'https']:
                log.error(f"Неправильный протокол {filter_type}.")
                error = True
                continue

            host_and_path = url['value'].split('://')[1]
            urlpath_regexes = [host_and_path[host_and_path.find('/'):]]
            url_regex = host_and_path[:host_and_path.find('/')]

            uuid = add_appfilter(api, f"IoC_K_{url_regex}", url_regex, urlpath_regexes, filter_type, config_uuid)
            if uuid == None:
                error = True
                continue

            if filter_type == 'http':
                malicious_http_uuids.append(uuid)
            elif filter_type == 'https':
                malicious_https_uuids.append(uuid)

        if len(malicious_http_uuids) > 0:
            http_group = add_appfilter_group(api, 'IoC_K_URL_HTTP_Group', 'http', config_uuid)
            if not http_group == None:
                add_to_group(api, http_group, malicious_http_uuids, config_uuid)
            else:
                error = True

        if len(malicious_https_uuids) > 0:
            https_group = add_appfilter_group(api, 'IoC_K_URL_HTTPS_Group', 'https', config_uuid)
            if not https_group == None:
                add_to_group(api, https_group, malicious_https_uuids, config_uuid)
            else:
                error = True

        print('[\033[92;1m+\033[0m] Импорт вредоносных URL завершён.\n')
        log.info(f"Импорт вредоносных URL завершён.")


    len_domains = len(domains)
    if len_domains > 0:
        print(f"[*] Импорт {len_domains} вредоносных FQDN.")
        log.info(f"Импорт {len_domains} вредоносных FQDN.")
        i = 0
        malicious_domains = []
        for domain in domains:
            draw_progress(i, 0, len_domains, 40, error)
            i += 1

            fqdn = domain.get('value')
            uuid = add_dnsrecord(api, f"IoC_K_{fqdn}", fqdn, config_uuid)
            if uuid == None:
                error = True
                continue

            malicious_domains.append(uuid)

        if len(malicious_domains) > 0:
            domains_group = add_dnsrecord_group(api, 'IoC_K_Domain_Group', config_uuid)
            if not domains_group == None:
                add_to_group(api, domains_group, malicious_domains, config_uuid)
            else:
                error = True

        print('[\033[92;1m+\033[0m] Импорт вредоносных FQDN завершён.\n')
        log.info(f"Импорт вредоносных FQDN завершён.")

    len_hashes = len(hashes)
    ecap_service = None
    if len_hashes > 0:
        i = 0
        print(f"[*] Импорт {len_hashes} пользовательских хэшей.")
        log.info(f"Импорт {len_hashes} пользовательских хэшей.")
        user_hashes_obj = []
        for hash in hashes:
            draw_progress(i, 0, len_hashes, 40, error)
            i += 1
            user_hashes_obj.append(
                {
                    'name': hash.get('filename', ''),
                    'md5': hash.get('md5', ''),
                    'size': hash.get('filesize', 0)
                }
            )

        tempfile_name = "hashes.json"
        with open(tempfile_name, 'w') as f:
            json.dump(user_hashes_obj, f, indent=4, ensure_ascii=False)

        result = api.post_to_endpoint(f"{api._base_url_server}/upload-userfs", {'filename': tempfile_name}, {'file': open(tempfile_name, 'rb')})
        if '__all__' in result.keys():
            print('[\033[91;1m-\033[0m] Ошибка импорта пользовательских хэшей.')
            log.error(f"Ошибка импорта пользовательских хэшей.")
            for msg in fork_data.get('__all__', []):
                log.error(f"\t{msg.get('message', '')}")
        else:
            print('[\033[92;1m+\033[0m] Импорт пользовательских хэшей завершен.\n')
            log.info(f"Импорт пользовательских хэшей завершён.")

        os.unlink(tempfile_name)
        print(f"[*] Добавление ecap сервиса.")
        log.info(f"Добавление ecap сервиса.")
        ecap_service = add_ecap_service(api, config_uuid, 'IoC_K_ECAP', description='')
        if ecap_service == None:
            error = True
            print('[\033[91;1m-\033[0m] Ошибка добавления ecap сервиса.')
            log.error(f"Ошибка добавления ecap сервиса.")
        else:
            print(f"[\033[92;1m+\033[0m] Добавление ecap сервиса завершено.")
            log.info(f"Добавление ecap сервиса завершено.")

        print(f"[*] Добавление профиля обновления пользовательских хэшей.")
        log.info(f"Добавление профиля обновления пользовательских хэшей.")
        schedule_uuid = add_schedule(api, config_uuid)
        if schedule_uuid == None:
            error = True
        else:
            cgws = get_cgws_uuid_by_name(api, args.cgw_list)
            rule_uuid = add_installupdaterule(api, config_uuid, 'IoC: профиль обновления хэшей', schedule=schedule_uuid, install_on=cgws)

            if rule_uuid == None:
                error = True
                print('[\033[91;1m-\033[0m] Ошибка добавления профиля обновления.')
                log.error(f"Ошибка добавления профиля обновления.")
            else:
                print(f"[\033[92;1m+\033[0m] Добавление профиля обновления пользовательских хэшей завершено.")
                log.info(f"Добавление профиля обновления пользовательских хэшей завершено.")

    groups = []
    profile_uuid = None
    if ecap_service != None:
        groups.append(ecap_service)

    if http_group != None:
        groups.append(http_group)

    if https_group != None:
        groups.append(https_group)

    if groups != []:
        profile_uuid = add_app_profile(
            api=api,
            config_uuid=config_uuid,
            name="IoC_K_HTTPS_Profile",
            filter_type='https',
            deny_groups=groups
        )

    if args.create_rules:
        services = api.get_from_endpoint(f"{api.get_obj_url(config_uuid)}/service")
        http = find_object(services, 'HTTP')
        tls = find_object(services, 'TLS')
        if args.top_rules:
            error = create_hash_url_rules(api, config_uuid, [http, tls], profile_uuid, args.enable_rules, args.top_rules)
            error = create_domains_group_rules(api, config_uuid, domains_group, args.enable_rules, args.top_rules)
            error = create_ip_group_rules(api, config_uuid, ip_group, args.enable_rules, args.top_rules)

        else:
            error = create_ip_group_rules(api, config_uuid, ip_group, args.enable_rules, args.top_rules)
            error = create_domains_group_rules(api, config_uuid, domains_group, args.enable_rules, args.top_rules)
            error = create_hash_url_rules(api, config_uuid, [http, tls], profile_uuid, args.enable_rules, args.top_rules)

    api.commit_config(config_uuid)
    api.free_config_lock()
    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")
    log.info(f"Выполнено.")

    if error:
        print("[\033[91;1m-\033[0m]В процессе работы возникли ошибки, подробнее о них в лог файле.")

