import os
module_abspath = os.path.dirname(os.path.abspath(__file__))
os.environ['OPENSSL_CONF'] = f'{module_abspath}/openssl.cnf'
os.environ['OPENSSL_ENGINE_PATH'] = module_abspath

import requests
import urllib3
import json

# curl -u user:pass -k https://172.16.10.1:444/api-v1-objects/config
class ApiConnector:
    def __init__(self, ip, port, user, password):
        requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS = "ALL:@SECLEVEL=1"
        requests.packages.urllib3.disable_warnings()
        self._base_url_server = f'https://{ip}:{port}/api-v1-server'
        self._base_url_objects = f'https://{ip}:{port}/api-v1-objects'
        self._user = user
        self._password = password
        self.session = requests.Session()
        self.session.auth = (self._user, self._password)
        self.session.verify = False

    def __exit__(self, exc_type, exc_value, traceback):
        self.session.close()

    def __parse_json(self, buffer):
        json_obj = {}
        try:
            json_obj = json.loads(buffer.content.decode('utf-8'))
        except:
            print("Ошибка парсинга JSON")
        return json_obj

    def result_check(self, result):
        """
        Проверяет ответ от сервера на наличие ошибок и выводит их, если есть.

        Returns:
            Возвращает True, если ошибок нет, иначе - False.
        """
        if not type(result) is dict:
            return False

        if not 'uuid' in result.keys():
            for key in result.keys():
                msg_obj = result[key][0]
                print(f"[\033[91;1m-\033[0m] {key}: {msg_obj['message']}")
            return False

        return True

    def get_obj_url(self, config_uuid):
        """
        Возвращает конечную точку api-v1-objects/config.

        Returns:
            Возвращает строку.
        """
        if not config_uuid:
            print("Не указан UUID")
            return
        return f"{self._base_url_objects}/config/{config_uuid}"

    def get_srv_url(self, config_uuid):
        """
        Возвращает конечную точку api-v1-server/config.

        Returns:
            Возвращает строку.
        """
        if not config_uuid:
            print("Не указан UUID")
            return
        return f"{self._base_url_server}/config/{config_uuid}"

    def post_to_endpoint(self, url, obj_dict, obj_files=None):
        """
        Отправляет словарь на указанный URL методом POST.

        Args:
            url: URL для отправки.
            obj_dict: объект для отправки.
            obj_files: необязательный параметр, позволяющий передавать файлы. {"имя файла": файлоподобный объект}
        Returns:
            Возвращает словарь.
        """
        buffer = self.session.post(url=url, json=obj_dict, files=obj_files)
        return self.__parse_json(buffer)

    def put_to_endpoint(self, url, obj_dict, obj_files=None):
        """
        Отправляет словарь на указанный URL методом PUT.

        Args:
            url: URL для отправки.
            obj_dict: объект для отправки.
            obj_files: необязательный параметр, позволяющий передавать файлы. {"имя файла": файлоподобный объект}
        Returns:
            Возвращает словарь.
        """
        buffer = self.session.put(url=url, json=obj_dict, files=obj_files)
        return self.__parse_json(buffer)

    def delete_obj(self, url, uuid):
        """
        Отправляет запрос на удаление объекта на указанный URL.

        Args:
            url: URL для отправки.
            uuid: идентификатор объекта для удаления.
        Returns:
            Возвращает словарь.
        """
        buffer = self.session.delete(url=f"{url}/{uuid}")
        return self.__parse_json(buffer)

    def get_from_endpoint(self, url):
        """
        Отправляет запрос на указанный URL методом GET.

        Args:
            url: URL для отправки.
        Returns:
            Возвращает словарь.
        """
        buffer = self.session.get(url=url)
        return self.__parse_json(buffer)

    def get_file_from_endpoint(self, url, filename):
        """
        Отправляет запрос на указанный URL методом GET и записывает ответ в файл.

        Args:
            url: URL для отправки.
            filename: полный путь до файла для записи.
        """
        resp = self.session.get(url=url)

        if not resp.status_code == 200:
            print(f"Статус: {resp.status_code}")
            return

        with open(filename, 'wb') as f:
            f.write(resp.content)

    def config_lock_user(self):
        """
        Возвращает объект, описывающий блокировку конфига.

        Returns:
            Возвращает словарь.
        """
        url = f'{self._base_url_server}/config-lock-user'
        return self.get_from_endpoint(url)

    def set_config_lock(self):
        """
        Устанавливает блокировку конфига.

        Returns:
            Возвращает словарь со статусом.
        """
        # url = f'{self._base_url_server}/force-config-lock'
        url = f'{self._base_url_server}/acquire-config-lock'
        return self.post_to_endpoint(url, {})

    def fork_config(self, source='active'):
        """
        Создаёт форк активного конфига для изменений.

        Args:
            source: идентификатор исходного конфига. По умолчанию - active.
        Returns:
            Возвращает словарь с uuid форка.
        """
        url = f'{self._base_url_objects}/config'
        fields = {'name': 'new_config', 'subtype': 'adminedit', 'source': source}
        return self.post_to_endpoint(url, fields)

    def commit_config(self, config_uuid):
        """
        Запускает процесс слияния конфига с идентификатором uuid с активным.

        Args:
            config_uuid: идентификатор конфига для слияния с активным.
        Returns:
            Возвращает словарь со статусом.
        """
        if not config_uuid:
            print("Не указан UUID")
            return
        url = f'{self.get_srv_url(config_uuid)}/commit'
        return self.post_to_endpoint(url, {})

    def free_config_lock(self):
        """
        Снимает блокировку конфига.

        Returns:
            Возвращает словарь со статусом.
        """
        url = f'{self._base_url_server}/free-config-lock'
        return self.post_to_endpoint(url, {})

    def get_config_obj(self):
        """
        Возвращает объект, определяющий конфигурации.

        Returns:
            Возвращает словарь.
        """
        url = f'{self._base_url_objects}/config'
        return self.get_from_endpoint(url)

    def get_master_uuid(self):
        """
         Returns:
            Возвращает uuid master-конфигурации.
        """
        url = f'{self._base_url_objects}/config'
        config_obj = self.get_from_endpoint(url)

        master_uuid = None
        for cfg in config_obj['data']:
            if cfg['subtype'] == 'master':
                master_uuid = cfg['uuid']
                break

        return master_uuid

    def get_cgw_obj(self, config_uuid='active'):
        """
        Возвращает объект со свойствами узлов безопасности.

        Args:
            config_uuid: идентификатор конфига для извлечения объекта.
        Returns:
            Возвращает словарь.
        """
        url = f'{self.get_obj_url(config_uuid)}/cgw'
        return self.get_from_endpoint(url)

    def get_config_by_uuid(self, config_uuid='active'):
        """
        Возвращает конфигурацию по идентификатору.

        Args:
            config_uuid: Идентификатор необходимой конфигурации.
        Returns:
            возвращает словарь.
        """
        url = f'{self.get_srv_url(config_uuid)}/export-config?view=full'
        return self.get_from_endpoint(url)

    def get_cgw_config_by_hwserial(self, hwserial, config_uuid='active'):
        """
        Возвращает конфигурацию УБ по hwserial.

        Args:
            hwserial: Идентификатор УБ.
            config_uuid: идентификатор конфига.
        Returns:
            Возвращает словарь.
        """
        if not hwserial:
            print("Не указан hwserial")
            return

        url = f'{self.get_srv_url(config_uuid)}/export-config-for-cgw/{hwserial}?view=full'
        return self.get_from_endpoint(url)

    def install_policy_cgw(self, hwserial_list, config_uuid='active'):
        """
        Запускает процесс установки политики на УБ c определёнными hwserial.

        Args:
            hwserial_list: Список hwserial УБ для установки политики.
            config_uuid: Идентификатор конфига.
        """
        url = f'{self.get_srv_url(config_uuid)}/install-policy'
        fields = {'target': hwserial_list}
        return self.post_to_endpoint(url, fields)

    def import_fw_rules(self, objects_file, config_uuid):
        """
        Импортирует правила FW.

        Args:
            objects_file: Файл с правилами для импорта.
            config_uuid: Идентификатор конфига.
        Returns:
            Возвращает словарь со статусом и id задачи в случае успеха.
        """
        url = f'{self.get_srv_url(config_uuid)}/import-fw-rules'
        out_data = {}
        with open(objects_file, 'rb') as f:
            file_dict = {'objects_file': f}
            out_data = self.post_to_endpoint(url, {}, file_dict)

        return out_data

    def import_nat_rules(self, objects_file, config_uuid):
        """
        Импортирует правила NAT.

        Args:
            objects_file: Файл с правилами для импорта.
            config_uuid: Идентификатор конфига.
        Returns:
            Возвращает словарь со статусом и id задачи в случае успеха.
        """
        url = f'{self.get_srv_url(config_uuid)}/import-nat-rules'
        out_data = {}
        with open(objects_file, 'rb') as f:
            file_dict = {'objects_file': f}
            out_data = self.post_to_endpoint(url, {}, file_dict)

        return out_data

    def get_tasks(self):
        """
        Возвращает словарь со списком задач.
        """
        url = f'{self._base_url_objects}/task'
        return self.get_from_endpoint(url)

    def get_task(self, uuid):
        """
        Возвращает словарь с объектом задачи.
        """
        if uuid is None:
            return {}
        url = f'{self._base_url_objects}/task/{uuid}'
        return self.get_from_endpoint(url)

    def get_task_result(self, task_uuid):
        """
        Проверяет, выполнена ли задача

        Args:
            task_uuid: Идентификатор задачи.
        Returns:
            Возвращает процент выполнения задачи и сообщения об ошибках, если она не завершилась успешно.
        """
        tasks = self.get_task(task_uuid).get('data', [])
        if len(tasks) > 0:
            task = tasks[0]
            progress = task.get('processed', 100)
            if progress < 100:
                return progress, []

            if not task.get('status') == 'done':
                messages = task.get('messages', [])
                return progress, messages

        return 100, []
