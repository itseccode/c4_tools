from setuptools import setup
setup(name = 'c4_policy_install',
    version = '1.0',
    py_modules = ['c4_policy_install'],
    packages = ['c4_policy_install'],
    install_requires = ['c4_lib'],
    include_package_data = True,
    entry_points = {
        'console_scripts': [
                'c4_policy_install = c4_policy_install.__main__:cli',
        ]
    }
)
