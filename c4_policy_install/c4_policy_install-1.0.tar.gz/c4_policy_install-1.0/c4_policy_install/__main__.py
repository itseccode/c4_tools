#!/usr/bin/env python3
import argparse
import os
import sys

import c4_lib

def install_policy_all(api):
    """
    Запускает процесс установки политики на все УБ в конфигурации.
    """
    cgws = api.get_cgw_obj()
    hwserial_list = []
    for cgw in cgws['data']:
        hwserial_list.append(cgw['hwserial'])

    return api.install_policy_cgw(hwserial_list)

def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для установки политики на узлы конфигурации Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP узла.', type=str, required=True)
    parser.add_argument('--port', help='Порт узла.', default='444', type=str)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    if api is None:
        print('[\033[91;1m-\033[0m] Ошибка инициализации ApiConnector выход.')
        return

    install_policy_all(api)

    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")

if __name__ == "__main__":
    cli()