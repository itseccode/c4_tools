#!/usr/bin/env python3
import argparse
import os
import sys
import logging
import c4_lib
import pandas as pd
# pandas, xlrd

usage_field_dict = {
    "external": "external",
    "internal": "internal"
}

log = logging.getLogger(__name__)

def parse_xls_first_sheet(filename):
    xls = pd.ExcelFile(filename)
    sheet = xls.parse(0)
    return sheet.to_dict()


def draw_progress(i, min_i, max_i, size, error=False):
    color = 92 # green
    if error: color = 91 # red
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[{color}m{str_filler}{str_emptiness}\033[0m| {i - min_i} / {max_i - min_i} - \033[1m{percent}%\033[0m")
    sys.stdout.flush()
    if i == max_i:
        sys.stdout.write("\n")


def find_object_by_name(api, name, url):
    """Получаем объекты по url и ищем нужный"""
    objects = api.get_from_endpoint(url)
    for obj in objects.get('data', []):
        if obj.get('name') == name:
            return obj
    return None


def result_check(fields, result):
    """
    Проверяет возвращаемые данные и записыват ошибку в лог, если она есть

    :Parameters:
        fields
            dict {'name': 'имя объекта'...}.
        result
            возвращаемое значение от C4 API.

    :return:
        Возвращает False, если от API вернулась ошибка.
    """
    if not type(result) == dict:
        return False

    if not 'uuid' in result.keys():
        if 'message' in result.keys():
            log.error(' - '.join([fields.get('name', ''), result['message']]))
        else:
            for key in result.keys():
                msg_obj = result[key]
                if len(result[key]) > 0:
                    msg_obj = result[key][0]

                log.error(' - '.join([f"{fields.get('name', '')}", f"{key}: {msg_obj.get('message')}"]))

        return False

    return True


def cli():
    config = {}
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для автоматического создания VLAN в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -c config.xls

В файле настроек необходимо наличие следующих колонок:
    gateway_name - имя узла
    eth_name - имя родительского интерфейса для VLAN
    vlan_id - идентификатор VLAN
    vlan_ip - адерс VLAN
    vlan_prefix - маска VLAN
    vlan_topology - топология VLAN
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('-c','--config', help='Путь до файла настроек.', type=str)
    parser.add_argument('--log', help='Имя файла логирования', default=f"{os.path.basename(sys.argv[0])}.log", type=str)
    if sys.version_info.major == 3 and sys.version_info.minor < 9:
        parser.add_argument('-r', '--rewrite', help='Перезаписывать существующие VLAN. По умолчанию выключено.', action='store_true')
        parser.set_defaults(rewrite=False)
    else:
        parser.add_argument('-r', '--rewrite', help='Перезаписывать существующие VLAN. По умолчанию выключено.', action=argparse.BooleanOptionalAction)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    if sys.version_info.major == 3 and sys.version_info.minor < 9:
        logging.basicConfig(level=logging.INFO, filename=args.log,
        format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    else:
        logging.basicConfig(encoding='utf-8', level=logging.INFO, filename=args.log,
        format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    if not args.config is None:
        if not os.path.exists(args.config):
            print('[\033[91;1m-\033[0m] Файл настроек отсутствует.')
            log.error('Файл настроек отсутствует.')
            return

        config = parse_xls_first_sheet(args.config)
        for column in ['gateway_name', 'eth_name', 'vlan_id', 'vlan_ip', 'vlan_prefix', 'vlan_topology']:
            if not column in config.keys():
                print(f"[\033[91;1m-\033[0m] В файле настроек отсутствует колонка {column}.")
                log.error(f"В файле настроек отсутствует колонка {column}.")
                return

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        log.error('Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    config_lock_data = api.config_lock_user()
    if config_lock_data['admin'] != None:
        print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        log.error('Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС.')
        return

    api.set_config_lock()
    fork_data = api.fork_config()
    if not type(fork_data) is dict or 'uuid' not in fork_data.keys():
        print('[\033[91;1m-\033[0m] Ошибка блокировки конфига. Выход.')
        log.error('Ошибка блокировки конфига.')
        for msg in fork_data.get('__all__', []):
            print(f"\t{msg.get('message', '')}")
            log.error(msg.get('message', ''))
        api.free_config_lock()
        return

    config_uuid = fork_data['uuid']
    base_url = api.get_obj_url(config_uuid)

    cgws = {}
    resp_data = api.get_from_endpoint(f"{base_url}/cgw?view=interfaces")
    if 'data' in resp_data.keys():
        cgws = resp_data['data']
    else:
        print('[\033[91;1m-\033[0m] Ошибка получения данных с ЦУС. Выход.')
        log.error('Ошибка получения данных с ЦУС.')
        api.commit_config(config_uuid)
        api.free_config_lock()
        return

    error = False
    created_vlans = 0
    changed_vlans = 0
    skip_vlans = 0
    config_first_key = list(config.keys())[0]
    max_i = len(config[config_first_key])
    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        cgw_name = config['gateway_name'][i]
        eth_name = config['eth_name'][i]
        vlan_id = config['vlan_id'][i]
        cgw_obj = None
        eth_obj = None

        for cgw in cgws:
            if cgw.get('name') == cgw_name:
                cgw_obj = cgw
                break

        if cgw_obj == None:
            log.error(f"Отсутствует узел {cgw_name}.")
            error = True
            continue

        interfaces = {}
        data = api.get_from_endpoint(f"{base_url}/cgw/{cgw_obj.get('uuid')}?view=interfaces")
        data = data.get('data', [])
        if len(data) > 0:
            interfaces = data[0]

        for interface in interfaces.get('interfaces', []):
            if interface.get('name') == eth_name:
                eth_obj = interface
                break

        if eth_obj == None:
            log.error(f"Отсутствует интерфейс {eth_name}.")
            error = True
            continue

        vlan_exist_uuid = None
        found = False
        for vlan in interfaces.get('interfaces', []):
            if vlan.get('name') == f"{eth_name}.{vlan_id}":
                found = True
                vlan_exist_uuid = vlan.get('uuid')
                break

        if found:
            if not args.rewrite:
                log.info(f"VLAN {eth_name}.{vlan_id} существует. Пропуск.")
                skip_vlans += 1
                continue
            log.info(f"VLAN {eth_name}.{vlan_id} существует. Перезапись.")

        ip = config['vlan_ip'][i]
        mask = config['vlan_prefix'][i]
        vlan = {
            "addresses": [
                f"{ip}/{mask}"
            ],
            "vlan_id": vlan_id,
            "parent": eth_obj.get('uuid'),
            "usage": usage_field_dict.get(
                config["vlan_topology"][i], "none"
            )
        }

        if vlan_exist_uuid == None:
            resp = api.post_to_endpoint(f"{base_url}/interfacevlan", vlan)
            if result_check({'name': f"{eth_name}.{vlan_id}"}, resp):
                created_vlans += 1
        else:
            resp = api.put_to_endpoint(f"{base_url}/interfacevlan/{vlan_exist_uuid}", vlan)
            if result_check({'name': f"{eth_name}.{vlan_id}"}, resp):
                changed_vlans += 1

    api.commit_config(config_uuid)
    api.free_config_lock()
    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m\n")
    print(f"VLAN создано: {created_vlans}")
    print(f"VLAN изменено: {changed_vlans}")
    print(f"VLAN оставлены без изменений: {skip_vlans}")
