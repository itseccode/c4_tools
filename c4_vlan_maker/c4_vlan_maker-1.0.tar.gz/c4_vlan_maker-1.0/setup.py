from setuptools import setup
setup(name = 'c4_vlan_maker',
    version = '1.0',
    py_modules = ['c4_vlan_maker'],
    packages = ['c4_vlan_maker'],
    install_requires = ['c4_lib'],
    include_package_data = True,
    entry_points = {
        'console_scripts': [
                'c4_vlan_maker = c4_vlan_maker.__main__:cli',
        ]
    }
)
