#!/usr/bin/env python3
import argparse
import os
import sys
import logging
import c4_lib
import pandas as pd
# pandas, xlrd, openpyxl

log = logging.getLogger(__name__)
proto = {
    'tcp': 6,
    'udp': 17
}


def parse_xls_sheet(filename, index: int) -> pd.DataFrame:
    xls = pd.ExcelFile(filename)
    return xls.parse(index)


def draw_progress(i, min_i, max_i, size, error=False):
    color = 92 # green
    if error: color = 91 # red
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[{color}m{str_filler}{str_emptiness}\033[0m| {i - min_i} / {max_i - min_i} - \033[1m{percent}%\033[0m")
    sys.stdout.flush()
    if i == max_i:
        sys.stdout.write("\n")


def is_empty(check_string):
    if check_string == None:
        return True

    if type(check_string) == str and check_string.lower() in ['nan', 'none', 'any', '']:
        return True

    if type(check_string) == float and pd.isna(check_string):
        return True

    return False


def result_check(fields, result):
    """
    Проверяет возвращаемые данные и записыват ошибку в лог, если она есть

    Args:
        fields: dict {'name': 'имя объекта'...}.
        result: возвращаемое значение от C4 API.
    Returns:
        Возвращает False, если от API вернулась ошибка.
    """
    if not type(result) == dict:
        return False

    if not 'uuid' in result.keys():
        if 'message' in result.keys():
            log.error(' - '.join([fields.get('name', ''), result['message']]))
        else:
            for key in result.keys():
                msg_obj = result[key]
                if len(result[key]) > 0:
                    msg_obj = result[key][0]

                log.error(' - '.join([f"{fields.get('name', '')}", f"{key}: {msg_obj.get('message')}"]))

        return False

    return True


def find_object_by_name(api, name, url):
    """Получаем объекты по url и ищем нужный"""
    objects = api.get_from_endpoint(url)
    for obj in objects.get('data', []):
        if obj.get('name') == name:
            return obj
    return None


def parse_netobject(api, object_str, uuids_list, config_uuid):
    if is_empty(object_str):
        return True

    obj_list = object_str.strip().split(',')
    for ip in obj_list:
        uuid = add_netobject(api, ip.replace('/', '_'), ip, config_uuid)
        if uuid == None:
            return False
        else:
            uuids_list.append(uuid)

    return True


def add_netobject(api, name, current_addr, config_uuid, description=''):
    """
    Добавляет сетевой объект в конфиг с определённым uuid, если объект существует, то только возвращет его uuid.

    Args:
        name: имя.
        description: описание.
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/netobject'

    result = find_object_by_name(api, name, url)
    if not result is None:
        return result.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'ip': current_addr
    }

    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result.get('uuid')
    return None


def parse_service(api, object_str, uuids_list, config_uuid):
    if is_empty(object_str):
        return True

    services_list = object_str.strip().split(',')
    for service in services_list:
        splitted = service.split('/')
        proto_number = proto.get(splitted[0])
        dst_port = splitted[1]
        uuid = add_service(
            api,
            service.replace('/', '_'),
            proto_number,
            config_uuid,
            description='',
            src=None,
            dst=dst_port
        )

        if uuid == None:
            return False
        else:
            uuids_list.append(uuid)

    return True


def add_service(api, name, proto, config_uuid, description='', src=None, dst=None, icmp_type=None, icmp_code=None):
    """
    Добавляет сервис в конфиг с определённым uuid. Если сервис с таким именем существует, то возврашет uuid существующего.

    Args:
        name: имя.
        description: описание.
        proto: номер протокола.
        src: порт источника для сервисов с протоколами 6 (TCP) и 17 (UDP).
        dst: порт назначения для сервисов с протоколами 6 (TCP) и 17 (UDP).
        icmp_type: Тип ICMP (1).
        icmp_code: Код ICMP (1).
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает UUID при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/service'

    objects = api.get_from_endpoint(url)
    for obj in objects.get('data', []):
        if obj.get('name') == name and obj.get('proto') == proto:
            return obj.get('uuid')

    fields = {
        'name': name,
        'description': description,
        'proto': proto
    }

    if proto in [6, 17]:
        fields['src'] = src
        fields['dst'] = dst

    if proto == 1:
        fields['icmp_type'] = icmp_type
        fields['icmp_code'] = icmp_code

    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_fw_rule(api, name, src, dst, service, applications, logging, action, config_uuid, description=''):
    """
    Создаёт правило фильтрации в конфиге с определённым uuid.

    Args:
        name: имя правила.
        description: описание.
        src: список идентификаторов объектов-источников.
        dst: список идентификаторов объектов назначения.
        service: список сервисов.
        applications:
        rule_action: действие правила (pass, block, nocrypt)
        logging: логическое значение, определяющее включено ли логирование для правила.
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/fwrule'
    fields = {
        'name': name,
        'description': description,
        'src': src,
        'dst': dst,
        'service': service,
        'applications': applications,
        'rule_action': action,
        'logging': logging,
        'type': 'fwrule',
        'rule_position': {'last': True}
    }
    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_nat_rule(api, name, src, dst, service, nat_type, config_uuid, description='', value=None, port_value=None):
    """
    Создаёт правило трансляции в конфиге с определённым uuid.

    Args:
        name: имя правила.
        description: описание.
        src: список идентификаторов объектов-источников.
        dst: список идентификаторов объектов назначения.
        service: список сервисов.
        value: сетевой объект транслированного пакета (строка uuid).
        port_value: сервис транслированного пакета (строка uuid).
        nat_type: тип NAT (original, masquerade, dynamic, dnat, static).
        config_uuid: идентификатор конфига для добавления.
    Returns:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/natrule'
    fields = {
        'name': name,
        'description': description,
        'src': src,
        'dst': dst,
        'service': service,
        'address_type': None,
        'value': value,
        'port_type': None,
        'port_value': port_value,
        'nat_type': nat_type,
        'type': 'natrule',
        'rule_position': {'last': True}
    }
    if not value is None:
        fields['address_type'] = 'netobject'

    if not port_value is None:
        fields['port_type'] = 'service'

    result = api.post_to_endpoint(url, fields)
    if api.result_check(result):
        return result['uuid']
    return None


def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для автоматического создания правил в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -c config.xls

На первом листе должны находиться правила фильтрации, на втором - трансляции.

У правил фильтрации необходимо наличие следующих колонок:
    Name - имя правила
    Source - адреса источников
    Destination - адреса назначения
    Service - сервисы (протокол/порт)
    Description - описание правила

У правил трансляции необходимо наличие следующих колонок:
    Name - имя правила
    Original Source - адрес источника оригинального пакета
    Original Destination - адрес назначения оригинального пакета
    Original Service - сервисы (протокол/порт) оригинального пакета
    Translation Type - тип трансляции
    Translated Interface - интерфейс транслированного пакета
    Translated Address - адрес транслированного пакета
    Translated Service - сервис транслированного пакета
    Bi-directional - двунаправленный NAT (yes/no)
    Description - описание правила
''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('--log', help='Имя файла логирования', default=f"{os.path.basename(sys.argv[0])}.log", type=str)
    parser.add_argument('-c','--config', help='Путь до файла настроек.', type=str, required=True)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    if sys.version_info.major == 3 and sys.version_info.minor < 9:
        logging.basicConfig(level=logging.INFO, filename=args.log,
        format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    else:
        logging.basicConfig(encoding='utf-8', level=logging.INFO, filename=args.log,
        format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    if not os.path.exists(args.config):
        print('[\033[91;1m-\033[0m] Файл отсутствует.')
        log.error('Файл отсутствует.')
        return

    fw_sheet = parse_xls_sheet(args.config, 0)
    for column in ['Name', 'Source', 'Destination', 'Service']:
        if not column in fw_sheet.keys():
            print(f"[\033[91;1m-\033[0m] У правил фильтрации отсутствует колонка: {column}.")
            log.error(f"У правил фильтрации отсутствует колонка: {column}.")
            return

    nat_sheet = parse_xls_sheet(args.config, 1)
    for column in ['Name', 'Original Source', 'Original Destination', 'Original Service',
       'Translation Type', 'Translated Interface', 'Translated Address',
       'Translated Service', 'Bi-directional']:
            if not column in nat_sheet.keys():
                print(f"[\033[91;1m-\033[0m] У правил трансляции отсутствует колонка: {column}.")
                log.error(f"У правил трансляции отсутствует колонка: {column}.")
                return

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        log.error('Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    config_lock_data = api.config_lock_user()
    if config_lock_data == {}:
        return

    if config_lock_data['admin'] != None:
        print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        log.error('Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС.')
        return

    api.set_config_lock()
    fork_data = api.fork_config()
    if not type(fork_data) is dict or 'uuid' not in fork_data.keys():
        print('[\033[91;1m-\033[0m] Ошибка блокировки конфига. Выход.')
        log.error('Ошибка блокировки конфига.')
        for msg in fork_data.get('__all__', []):
            print(f"\t{msg.get('message', '')}")
            log.error(msg.get('message', ''))
        api.free_config_lock()
        return

    config_uuid = fork_data['uuid']
    error = False
    max_i = len(fw_sheet.index)
    if max_i > 0:
        print("Обработка правил фильтрации")

    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        rule = fw_sheet.loc[i]
        name = rule.get('Name', '')
        description = rule.get('Description', '')

        src = []
        src_str = rule.get('Source')
        error = not parse_netobject(api, src_str, src, config_uuid)

        dst = []
        dst_str = rule.get('Destination')
        error = not parse_netobject(api, dst_str, dst, config_uuid)

        services = []
        services_str = rule.get('Service')
        error = not parse_service(api, services_str, services, config_uuid)

        uuid = add_fw_rule(api, name, src, dst, services, [], False, 'pass', config_uuid, description)
        if uuid == None:
            error = True

    max_i = len(nat_sheet.index)
    if max_i > 0:
        print("Обработка правил трансляции")

    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        rule = nat_sheet.loc[i]
        name = rule.get('Name', '')
        description = rule.get('Description', '')

        value = []
        value_str = rule.get('Translated Address', '')
        if type(value_str) == str and ',' in value_str:
            log.warning(f"Правило NAT {name} пропускается")
            continue

        error = not parse_netobject(api, value_str, value, config_uuid)
        if len(value) == 0:
            value = None
        else:
            value = value[0]

        src = []
        src_str = rule.get('Original Source')
        error = not parse_netobject(api, src_str, src, config_uuid)

        dst = []
        dst_str = rule.get('Original Destination')
        error = not parse_netobject(api, dst_str, dst, config_uuid)

        services = []
        services_str = rule.get('Original Service')
        error = not parse_service(api, services_str, services, config_uuid)

        port_value = []
        services_str = rule.get('Translated Service')
        error = not parse_service(api, services_str, port_value, config_uuid)
        if len(port_value) == 0:
            port_value = None
        else:
            port_value = port_value[0]

        nat_type = None
        trans_type = rule.get('Translation Type', '').lower()
        if 'none' in trans_type:
            nat_type = 'original'
        else:
            if 'snat' in trans_type:
                if 'dynamic' in trans_type:
                    if value == None:
                        nat_type = 'masquerade'
                    else:
                        nat_type = 'dynamic'

                if 'static' in trans_type:
                    if '-' in value_str:
                        nat_type = None
                    else:
                        nat_type = 'static'

            if 'dnat' in trans_type and 'static' in trans_type:
                if '/' in value_str or '-' in value_str:
                    nat_type = None
                else:
                    nat_type = 'dnat'

        if nat_type == 'static' and rule.get('Bi-directional', '').lower() == 'yes':
            new_value = None
            if len(src) > 0:
                new_value = src[0]

            uuid = add_nat_rule(api, f"{name}_mirrored", [value], dst, services, nat_type, config_uuid, description, new_value, port_value)
            if uuid == None:
                error = True

        if nat_type == None:
            log.warning(f"Правило NAT {name} пропускается")
        else:
            uuid = add_nat_rule(api, name, src, dst, services, nat_type, config_uuid, description, value, port_value)
            if uuid == None:
                error = True

    api.commit_config(config_uuid)
    api.free_config_lock()
    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")

