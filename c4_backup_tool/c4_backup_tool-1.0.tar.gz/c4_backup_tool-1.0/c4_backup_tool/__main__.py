#!/usr/bin/env python3
import argparse
import os
import sys
import pathlib
import time

import c4_lib

available_types = [
    'service',
    'netobject',
    'timeinterval',
    'group'
]

def draw_progress(i, min_i, max_i, size):
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[92m{str_filler}{str_emptiness}\033[0m| \033[1m{i - min_i} / {max_i - min_i} - {percent}%\033[0m")
    if i == max_i:
        sys.stdout.write("\n")
    sys.stdout.flush()

def is_done(api, task_uuid):
    tasks = api.get_task(task_uuid).get('data', [])
    if len(tasks) > 0:
        progress = tasks[0].get('processed', 100)
        if progress < 100:
            draw_progress(progress, 0, 100, 40)
            return False
    draw_progress(100, 0, 100, 40)
    return True

def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для экспорта резервных копий из Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 list
example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 create_backup --name backup1
example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 download --uuid 1 -o /path/to/folder
            ''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP узла.', type=str, required=True)
    parser.add_argument('--port', help='Порт узла.', default='444', type=str)

    parser.add_argument('-n', '--name', help='Имя резервной копии для создания.', type=str)
    parser.add_argument('--uuid', help='Идентификатор резервной копии для экспорта.', type=str)
    parser.add_argument('-o','--output_path', help='Путь до папки для сохранения.', type=str)

    parser.add_argument('cmd', choices=['list', 'create_backup', 'download'])
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    if args.cmd is None:
        parser.print_help()
        return

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    if api is None:
        print('[\033[91;1m-\033[0m] Ошибка инициализации ApiConnector выход.')
        return

    if args.cmd == 'list':
        backups = api.get_backup_list()
        for backup in backups.get('data', []):
            print(f"{backup['uuid']}: {backup['name']} - {backup['description']}")

    if args.cmd == 'create_backup':
        if args.name is None or args.name == '':
            parser.print_help()
            return

        config_lock_data = api.config_lock_user()
        if config_lock_data.get('admin', None) != None:
            print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
            return

        api.set_config_lock()

        task = api.create_backup(args.name)
        if not task.get('status') == 'ok':
            print(task)
            return

        while not is_done(api, task['tasks'][0]):
            time.sleep(2)

        api.free_config_lock()

    if args.cmd == 'download':
        if args.uuid is None or args.uuid == '' or args.output_path is None:
            parser.print_help()
            return

        output_path = pathlib.Path(args.output_path)
        if not output_path.exists():
            print("[*] Директория не существует, создание...")
            output_path.mkdir(parents=True, exist_ok=True)

        api.download_backup(args.uuid, output_path)

    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")

if __name__ == "__main__":
    cli()