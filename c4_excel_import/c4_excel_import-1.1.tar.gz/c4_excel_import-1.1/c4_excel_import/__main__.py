#!/usr/bin/env python3
import argparse
import os
import sys
import logging
import c4_lib
import pandas as pd
import numpy as np
# pandas, xlrd, openpyxl

log = logging.getLogger(__name__)
proto = {
    'tcp': 6,
    'udp': 17,
    'icmp': 1
}


def parse_xls_sheet(filename, index) -> pd.DataFrame:
    xls = pd.ExcelFile(filename)
    return xls.parse(index)


def draw_progress(i, min_i, max_i, size, error=False):
    color = 92 # green
    if error: color = 91 # red
    sys.stdout.write("\033[G")
    i += 1
    progress_percent = (max_i - min_i) / size
    progress = round((i - min_i) / progress_percent)
    str_filler = "█" * progress
    str_emptiness = " " * (size - progress)
    percent = round((i - min_i) / ((max_i - min_i) / 100))
    sys.stdout.write(f"|\033[{color}m{str_filler}{str_emptiness}\033[0m| {i - min_i} / {max_i - min_i} - \033[1m{percent}%\033[0m")
    sys.stdout.flush()
    if i == max_i:
        sys.stdout.write("\n")


def is_empty(check_string):
    if check_string == None:
        return True

    if type(check_string) == str and check_string.lower() in ['nan', 'none', 'any', '']:
        return True

    if type(check_string) == float and pd.isna(check_string):
        return True

    if 'numpy' in type(check_string).__module__ and np.isnan(check_string):
        return True

    return False


def result_check(fields, result):
    """
    Проверяет возвращаемые данные и записыват ошибку в лог, если она есть

    :Parameters:
        fields
            dict {'name': 'имя объекта'...}.
        result
            Возвращаемое значение от C4 API.

    :return:
        Возвращает False, если от API вернулась ошибка.
    """
    if not type(result) == dict:
        return False

    if not 'uuid' in result.keys():
        if 'message' in result.keys():
            log.error(' - '.join([fields.get('name', ''), result['message']]))
        else:
            for key in result.keys():
                msg_obj = result[key]
                if len(result[key]) > 0:
                    msg_obj = result[key][0]

                log.error(' - '.join([f"{fields.get('name', '')}", f"{key}: {msg_obj.get('message')}"]))

        return False

    return True


def find_object_by_name(api, name, url):
    """Получаем объекты по url и ищем нужный"""
    objects = api.get_from_endpoint(url)
    for obj in objects.get('data', []):
        if obj.get('name') == name:
            return obj
    return None


def parse_obj_cell(object_str, netobjs, netobj_groups):
    out = []
    if is_empty(object_str):
        return []

    for obj in object_str.split(','):
        for netobj in netobjs:
            if obj == netobj['name']:
                out.append(netobj['uuid'])
                break

        for netobj in netobj_groups:
            if obj == netobj['name']:
                out.append(netobj['uuid'])
                break

    return out


def add_netobject(api, name, current_addr, config_uuid, description=''):
    """
    Добавляет сетевой объект в конфиг с определённым uuid, если объект существует, то только возвращет его uuid.

    :Parameters:
        name
            Имя.
        current_addr
            IP адрес объекта, подсети или диапазона.
        description
            Описание.
        config_uuid
            Идентификатор конфига для добавления.

    :return:
        Возвращает uuid объекта при успешном добавлении и True, если объект с таким имененм уже есть.
    """
    url = f'{api.get_obj_url(config_uuid)}/netobject'

    result = find_object_by_name(api, name, url)
    if not result is None:
        return result.get('uuid'), True

    fields = {
        'name': name,
        'description': description,
        'ip': current_addr
    }

    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result.get('uuid'), False
    return None, False


def add_service(api, name, proto, config_uuid, description='', src=None, dst=None, icmp_type=None, icmp_code=None):
    """
    Добавляет сервис в конфиг с определённым uuid. Если сервис с таким именем существует, то возврашет uuid существующего.

    :Parameters:
        name
            Имя.
        description
            Описание.
        proto
            Номер протокола.
        src
            Порт источника для сервисов с протоколами 6 (TCP) и 17 (UDP).
        dst
            Порт назначения для сервисов с протоколами 6 (TCP) и 17 (UDP).
        icmp_type
            Тип ICMP (1).
        icmp_code
            Код ICMP (1).
        config_uuid
            Идентификатор конфига для добавления.

    :return:
        Возвращает UUID при успешном добавлении и True, если объект уже есть.
    """
    url = f'{api.get_obj_url(config_uuid)}/service'

    objects = api.get_from_endpoint(url)
    for obj in objects.get('data', []):
        if obj.get('name') == name and obj.get('proto') == proto:
            return obj.get('uuid'), True

    fields = {
        'name': name,
        'description': description,
        'proto': proto
    }

    if proto in [6, 17]:
        fields['src'] = src
        fields['dst'] = dst

    if proto == 1:
        fields['icmp_type'] = icmp_type
        fields['icmp_code'] = icmp_code

    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid'], False
    return None, False


def add_fw_rule(api, config_uuid, name, action='block', enabled=False, src=[], dst=[], service=[], applications=[], app_profile=None, logging=False, install_on=[], description='', first_position=False):
    """
    Создаёт правило фильтрации в конфиге с определённым uuid.

    :Parameters:
        api
            Объект c4_lib
        config_uuid
            Идентификатор конфига для добавления.
        name : str
            Имя правила.
        action : str
            Действие правила (pass, block, nocrypt)
        enabled : bool
            Определяет, активно ли правило
        src : list
            Список идентификаторов объектов источников.
        dst : list
            Список идентификаторов объектов назначения.
        service : list
            Список сервисов.
        applications : list
            Протокол/приложение.
        install_on : list
            Список УБ для установки правила.
        app_profile
            uuid профиля
        logging : bool
            Логическое значение, определяющее включено ли логирование для правила.
        description : str
            Описание.
        first_position : str
            Позиция создаваемого правила (first - первое, last - последнее).

    :return:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/fwrule'
    fields = {
        'name': name,
        'is_enabled': enabled,
        'description': description,
        'src': src,
        'dst': dst,
        'service': service,
        'applications': applications,
        'install_on': install_on,
        'rule_action': action,
        'logging': logging,
        'app_profile': app_profile,
        'type': 'fwrule',
        'rule_position': 'first' if first_position else 'last'
    }
    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_nat_rule(api, name, enabled, src, dst, service, install_on, nat_type, config_uuid, description='', value=None, port_value=None):
    """
    Создаёт правило трансляции в конфиге с определённым uuid.

    :Parameters:
        name
            Имя правила.
        description
            Описание.
        src
            Список идентификаторов объектов источников.
        dst
            Список идентификаторов объектов назначения.
        service
            Список сервисов.
        value
            Сетевой объект транслированного пакета (строка uuid).
        port_value
            Сервис транслированного пакета (строка uuid).
        nat_type
            Тип NAT (original, masquerade, dynamic, dnat, static).
        config_uuid
            Идентификатор конфига для добавления.

    :return:
        Возвращает uuid объекта при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/natrule'
    fields = {
        'name': name,
        'is_enabled':enabled,
        'description': description,
        'src': src,
        'dst': dst,
        'service': service,
        'install_on': install_on,
        'address_type': None,
        'value': value,
        'port_type': None,
        'port_value': port_value,
        'nat_type': nat_type,
        'type': 'natrule',
        'rule_position': {'last': True}
    }
    if not value is None:
        fields['address_type'] = 'netobject'

    if not port_value is None:
        fields['port_type'] = 'service'

    result = api.post_to_endpoint(url, fields)
    if result_check(fields, result):
        return result['uuid']
    return None


def add_group(api, config_uuid, name, description, subtype='netobject'):
    """
    Добавляет группу сетевых объектов.

    :Parameters:
        name
            имя объекта

    :return:
        Возвращает uuid при успешном добавлении и True, если объект с таким имененм уже есть.
    """
    url = f'{api.get_obj_url(config_uuid)}/group'

    groups = api.get_from_endpoint(url)
    if type(groups) is dict:
        for group in groups.get('data', []):
            if group.get('name') == name and group.get('subtype') == subtype:
                return group.get('uuid'), True

    fields = {'name': name, 'description': description, 'subtype': subtype}
    obj_data = api.post_to_endpoint(url, fields)

    if result_check(fields, obj_data):
        return obj_data['uuid'], False
    return None, False


def add_to_group(api, config_uuid, name, uuid, members):
    """
    Добавляет объекты в группу.

    :Parameters:
        uuid
            Идентификатор группы.
        members
            Список идентификаторов объектов.

    :return:
        Возвращает uuid при успешном добавлении.
    """
    url = f'{api.get_obj_url(config_uuid)}/group/{uuid}'
    result_check(
        {'name': name},
        api.put_to_endpoint(url, {'members': members})
    )


def parse_NetObjGroup_sheet(api, config_uuid, xls_filename):
    groups = []
    error = False
    sheet = parse_xls_sheet(xls_filename, 'NetObjGroup')
    if not 'Name' in sheet.keys():
        print(f"[\033[91;1m-\033[0m] У групп сетевых объектов отсутствует колонка: Name.")
        log.error(f"У групп сетевых объектов отсутствует колонка: Name.")
        return []

    max_i = len(sheet.index)
    if max_i > 0:
        log.info(f"Обработка групп сетевых объектов")
        print(f"Обработка групп сетевых объектов")

    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        group = sheet.loc[i]
        name = group.get('Name')
        if is_empty(name):
            log.error(f"У группы сетевых обхектов нет имени! Строка: {i + 2}")
            continue

        description = group.get('Description')
        if is_empty(description): description = ''

        uuid, exist = add_group(api, config_uuid, name[:31], description, subtype='netobject')
        if uuid != None:
            groups.append({'name': name, 'uuid': uuid, 'members': []})
        else:
            error = True

        if exist:
            log.warning(f"Группа сетевых объектов уже существует! Строка: {i + 2}, имя: {name}")

    return groups


def parse_ServiceGroup_sheet(api, config_uuid, xls_filename):
    groups = []
    error = False
    sheet = parse_xls_sheet(xls_filename, 'ServiceGroup')
    if not 'Name' in sheet.keys():
        print(f"[\033[91;1m-\033[0m] У групп сервисов отсутствует колонка: Name.")
        log.error(f"У групп сервисов отсутствует колонка: Name.")
        return []

    max_i = len(sheet.index)
    if max_i > 0:
        log.info(f"Обработка групп сервисов")
        print(f"Обработка групп сервисов")

    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        group = sheet.loc[i]
        name = group.get('Name')
        if is_empty(name):
            log.error(f"У группы сервисов нет имени! Строка: {i + 2}")
            continue

        description = group.get('Description')
        if is_empty(description): description = ''

        uuid, exist = add_group(api, config_uuid, name[:31], description, subtype='service')
        if uuid != None:
            groups.append({'name': name, 'uuid': uuid, 'members': []})
        else:
            error = True

        if exist:
            log.warning(f"Группа сервисов уже существует! Строка: {i + 2}, имя: {name}")

    return groups


def parse_NetObj_sheet(api, config_uuid, xls_filename, groups):
    objs = []
    error = False
    sheet = parse_xls_sheet(xls_filename, 'NetObj')
    for column in ['Name', 'Value']:
        if not column in sheet.keys():
            print(f"[\033[91;1m-\033[0m] У сетевых объектов отсутствует колонка: {column}.")
            log.error(f"У сетевых объектов отсутствует колонка: {column}.")
            return []

    max_i = len(sheet.index)
    if max_i > 0:
        log.info(f"Обработка сетевых объектов")
        print(f"Обработка сетевых объектов")

    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        obj = sheet.loc[i]
        name = obj.get('Name')
        if is_empty(name):
            log.error(f"У сетевого объекта нет имени! Строка: {i + 2}")
            continue

        value = obj.get('Value')
        if is_empty(value):
            log.error(f"{name} - value сетевого объекта в неправильном формате. Строка: {i + 2}")
            continue

        description = obj.get('Description')
        if is_empty(description): description = ''
        group = obj.get('Group')

        uuid, exist = add_netobject(api, name[:31], current_addr=value, config_uuid=config_uuid, description=description)
        if uuid != None:
            objs.append({'name': name, 'uuid': uuid})
            for g in groups:
                if g['name'] == group:
                    g['members'].append(uuid)
                    break
        else:
            log.error(f"Ошибка при создании сетевого объекта! Строка: {i + 2}")
            error = True

        if exist:
            log.warning(f"Сетевой объект уже существует! Строка: {i + 2}, имя: {name}")

    return objs


def parse_Service_sheet(api, config_uuid, xls_filename, groups):
    objs = []
    error = False
    sheet = parse_xls_sheet(xls_filename, 'Service')
    for column in ['Name', 'Value']:
        if not column in sheet.keys():
            print(f"[\033[91;1m-\033[0m] У сервисов отсутствует колонка: {column}.")
            log.error(f"У сервисов отсутствует колонка: {column}.")
            return []

    max_i = len(sheet.index)
    if max_i > 0:
        log.info(f"Обработка сервисов")
        print(f"Обработка сервисов")

    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        obj = sheet.loc[i]
        name = obj.get('Name')
        if is_empty(name):
            log.error(f"У сервиса нет имени! Строка: {i + 2}")
            continue

        value = obj.get('Value')
        if is_empty(value):
            log.error(f"{name} - value сервиса в неправильном формате. Строка: {i + 2}")
            continue

        description = obj.get('Description')
        if is_empty(description): description = ''
        group = obj.get('Group')

        if value.find('/') < 0:
            log.error(f"{name} - value сервиса в неправильном формате. Строка: {i + 2}")
            error = True
            continue

        values = value.split('/')
        uuid = None
        exist = False
        if len(values) == 3:
            first = values[1]
            if first == '-': first = None

            second = values[2]
            if second == '-': second = None

            if values[0].lower() == 'tcp':
                uuid, exist = add_service(api, name[:31], 6, config_uuid, description=description, src=first, dst=second)

            if values[0].lower() == 'udp':
                uuid, exist = add_service(api, name[:31], 17, config_uuid, description=description, src=first, dst=second)

            if values[0].lower() == 'icmp':
                uuid, exist = add_service(api, name[:31], 1, config_uuid, description=description, src=None, dst=None, icmp_type=first, icmp_code=second)

        if values[0].lower() == 'ip' and len(values) == 2:
            uuid, exist = add_service(api, name[:31], values[1], config_uuid, description=description)

        if uuid != None:
            objs.append({'name': name, 'uuid': uuid})
            for g in groups:
                if g['name'] == group:
                    g['members'].append(uuid)
                    break
        else:
            log.error(f"Ошибка при создании сервиса! Строка: {i + 2}")
            error = True

        if exist:
            log.warning(f"Сервис уже существует! Строка: {i + 2}, имя: {name}")

    return objs


def parse_Gateway_sheet(api, config_uuid, xls_filename):
    gateways = []
    sheet = parse_xls_sheet(xls_filename, 'Gateway')
    if not 'Name' in sheet.keys():
        print(f"[\033[91;1m-\033[0m] У УБ отсутствует колонка: Name.")
        log.error(f"У УБ отсутствует колонка: Name.")
        return []

    url = f'{api.get_obj_url(config_uuid)}/cgw'
    objects = api.get_from_endpoint(url)
    cgws = objects.get('data', [])

    url = f'{api.get_obj_url(config_uuid)}/group'
    objects = api.get_from_endpoint(url)
    groups = objects.get('data', [])

    max_i = len(sheet.index)
    if max_i > 0:
        log.info(f"Обработка УБ")
        print(f"Обработка УБ")

    error = False
    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        obj = sheet.loc[i]
        name = obj.get('Name')
        if is_empty(name):
            log.error(f"У УБ не задано имя! Строка: {i + 2}")
            error = True
            continue

        Found = False
        for cgw in cgws:
            if cgw.get('name') == name and cgw.get('uuid') != None:
                gateways.append({'name': name, 'uuid': cgw.get('uuid')})
                Found = True
                break

        if not Found:
            for grp in groups:
                if grp.get('type') == 'cgw' and grp.get('name') == name:
                    gateways.append({'name': name, 'uuid': grp.get('uuid')})
                    Found = True
                    break

        if not Found:
            log.warning(f"УБ не найден! Строка: {i + 2}, имя: {name}")

    return gateways


def cli():
    parser = argparse.ArgumentParser(
            formatter_class=argparse.RawTextHelpFormatter,
            prog = f"\n\n{os.path.basename(sys.argv[0])}",
            description = 'Утилита для автоматического создания правил в Континент 4.',
            epilog = f'''example: {os.path.basename(sys.argv[0])} -u user:pass --ip 172.16.10.1 -c config.xls''',
            add_help = False
        )
    parser.add_argument('-h', '--help', action='help', default=argparse.SUPPRESS, help='Показать текущее сообщение помощи и выйти.')
    parser.add_argument('-u', '--creds', help='Реквизиты в формате user:pass', type=str, required=True)
    parser.add_argument('--ip', help='IP сервера.', type=str, required=True)
    parser.add_argument('--port', help='Порт сервера.', default='444', type=str)
    parser.add_argument('--log', help='Имя файла логирования', default=f"{os.path.basename(sys.argv[0])}.log", type=str)
    parser.add_argument('-c','--config', help='Путь до файла настроек.', type=str, required=True)
    args = parser.parse_args(args=None if sys.argv[1:] else ['--help'])

    if sys.version_info.major == 3 and sys.version_info.minor < 9:
        logging.basicConfig(level=logging.INFO, filename=args.log,
        format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    else:
        logging.basicConfig(encoding='utf-8', level=logging.INFO, filename=args.log,
        format='%(asctime)s %(levelname)-8s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    if not os.path.exists(args.config):
        print('[\033[91;1m-\033[0m] Файл отсутствует.')
        log.error('Файл отсутствует.')
        return

    xls = pd.ExcelFile(args.config)
    not_found = False
    for sheet in ['FwRule', 'NatRule', 'NetObj', 'NetObjGroup', 'Service', 'ServiceGroup', 'Gateway']:
        if not sheet in xls.sheet_names:
            print(f"[\033[91;1m-\033[0m] Лист {sheet} отсутствует.")
            log.error(f"Лист {sheet} отсутствует.")
            not_found = True

    if not_found:
        return

    del xls

    colon_index = args.creds.find(':')
    if colon_index < 0:
        print('[\033[91;1m-\033[0m] Неверный формат реквизитов.')
        log.error('Неверный формат реквизитов.')
        return

    user = args.creds[:colon_index]
    password = args.creds[colon_index + 1:]
    api = c4_lib.ApiConnector(args.ip, args.port, user, password)

    config_lock_data = api.config_lock_user()
    if config_lock_data == {}:
        return

    if config_lock_data['admin'] != None:
        print('[\033[91;1m-\033[0m] Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС. Выход.')
        log.error('Перед использованием убедитесь, что в МК сохранены все изменения и разорвано соединение с ЦУС.')
        return

    api.set_config_lock()
    fork_data = api.fork_config()
    if not type(fork_data) is dict or 'uuid' not in fork_data.keys():
        print('[\033[91;1m-\033[0m] Ошибка блокировки конфига. Выход.')
        log.error('Ошибка блокировки конфига.')
        for msg in fork_data.get('__all__', []):
            print(f"\t{msg.get('message', '')}")
            log.error(msg.get('message', ''))
        api.free_config_lock()
        return

    config_uuid = fork_data['uuid']
    error = False

    gateways = parse_Gateway_sheet(api, config_uuid, args.config)
    # {'name': '', 'uuid': '', 'members': []}
    netobj_groups = parse_NetObjGroup_sheet(api, config_uuid, args.config)
    service_groups = parse_ServiceGroup_sheet(api, config_uuid, args.config)

    # {'name': '', 'uuid': ''}
    netobjs = parse_NetObj_sheet(api, config_uuid, args.config, netobj_groups)
    services = parse_Service_sheet(api, config_uuid, args.config, service_groups)

    for grp in netobj_groups:
        add_to_group(api, config_uuid, grp['name'], grp['uuid'], grp['members'])

    for grp in service_groups:
        add_to_group(api, config_uuid, grp['name'], grp['uuid'], grp['members'])

    fw_sheet = parse_xls_sheet(args.config, 'FwRule')
    for column in ['State', 'Name', 'Source', 'Destination', 'Service', 'Gateway', 'Action', 'Log']:
        if not column in fw_sheet.keys():
            print(f"[\033[91;1m-\033[0m] У правил фильтрации отсутствует колонка: {column}.")
            log.error(f"У правил фильтрации отсутствует колонка: {column}.")

    max_i = len(fw_sheet.index)
    if max_i > 0:
        print("Обработка правил фильтрации")

    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        rule = fw_sheet.loc[i]
        name = rule.get('Name')
        if is_empty(name): name = ''

        if len(name) > 32:
            log.warning(f"Правило {name} - слишком длинное имя! Строка: {i + 2}")
            name = name[:31]

        description = rule.get('Description')
        if is_empty(description): description = ''

        log_value = rule.get('Log')
        if is_empty(log_value):
            log.error(f"Некорректное значение Log правила фильтрации! Строка: {i + 2}, имя: {name}")
            error = True
            continue
        rule_log = True if log_value == 'Yes' else False

        act = rule.get('Action')
        if is_empty(act):
            log.error(f"Некорректное значение Action правила фильтрации! Строка: {i + 2}, имя: {name}")
            error = True
            continue
        action = 'pass' if act == 'Allow' else 'block'

        state = rule.get('State')
        if is_empty(state):
            log.error(f"Некорректное значение State правила фильтрации! Строка: {i + 2}, имя: {name}")
            error = True
            continue
        enabled = True if state == 'On' else False

        src_str = rule.get('Source')
        src = parse_obj_cell(src_str, netobjs, netobj_groups)

        dst_str = rule.get('Destination')
        dst = parse_obj_cell(dst_str, netobjs, netobj_groups)

        services_str = rule.get('Service')
        services_uuids = parse_obj_cell(services_str, services, service_groups)

        gateway_str = rule.get('Gateway')
        install_on = parse_obj_cell(gateway_str, gateways, [])

        uuid = add_fw_rule(
            api=api,
            config_uuid=config_uuid,
            name=name,
            enabled=enabled,
            src=src,
            dst=dst,
            install_on=install_on,
            service=services_uuids,
            logging=rule_log,
            action=action,
            description=description
        )

        if uuid == None:
            error = True

    nat_sheet = parse_xls_sheet(args.config, 'NatRule')
    for column in ['State', 'Name', 'OrigSource', 'OrigDestination', 'OrigService', 'TransSource', 'TransDestination', 'TransService', 'Gateway', 'Type']:
        if not column in nat_sheet.keys():
            print(f"[\033[91;1m-\033[0m] У правил трансляции отсутствует колонка: {column}.")
            log.error(f"У правил трансляции отсутствует колонка: {column}.")

    max_i = len(nat_sheet.index)
    if max_i > 0:
        print("Обработка правил трансляции")

    for i in range(max_i):
        draw_progress(i, 0, max_i, 40, error)
        rule = nat_sheet.loc[i]
        name = rule.get('Name')
        if is_empty(name): name = ''

        if len(name) > 32:
            log.warning(f"Правило {name} - слишком длинное имя! Строка: {i + 2}")
            name = name[:31]

        description = rule.get('Description')
        if is_empty(description): description = ''

        state = rule.get('State')
        if is_empty(state):
            log.error(f"Некорректное значение State правила трансляции! Строка: {i + 2}, имя: {name}")
            error = True
            continue
        enabled = True if state == 'On' else False

        src_str = rule.get('OrigSource')
        src = parse_obj_cell(src_str, netobjs, netobj_groups)

        dst_str = rule.get('OrigDestination')
        dst = parse_obj_cell(dst_str, netobjs, netobj_groups)

        services_str = rule.get('OrigService')
        services_uuids = parse_obj_cell(services_str, services, service_groups)

        gateway_str = rule.get('Gateway')
        install_on = parse_obj_cell(gateway_str, gateways, [])

        value_src_str = rule.get('TransSource')
        value_src = parse_obj_cell(value_src_str, netobjs, netobj_groups)
        if len(value_src) == 0:
            value_src = None
        else:
            value_src = value_src[0]

        value_dst_str = rule.get('TransDestination')
        value_dst = parse_obj_cell(value_dst_str, netobjs, netobj_groups)
        if len(value_dst) == 0:
            value_dst = None
        else:
            value_dst = value_dst[0]

        port_value_str = rule.get('TransService')
        port_value = parse_obj_cell(port_value_str,services, service_groups)
        if len(port_value) == 0:
            port_value = None
        else:
            port_value = port_value[0]

        nat_type = rule.get('Type')
        if is_empty(state):
            log.error(f"Некорректное значение Type правила трансляции! Строка: {i + 2}, имя: {name}")
            error = True
            continue
        value = None
        match nat_type:
            case 'Original':
                nat_type = 'original'
            case 'Hide':
                nat_type = 'masquerade'
            case 'Source':
                nat_type = 'dynamic'
                value = value_src
            case 'Destination':
                nat_type = 'dnat'
                value = value_dst
            case 'Netmap':
                nat_type = 'static'
                value = value_src

        uuid = add_nat_rule(
            api=api,
            name = name,
            enabled=enabled,
            src=src,
            dst=dst,
            service=services_uuids,
            install_on=install_on,
            nat_type=nat_type,
            config_uuid=config_uuid,
            description=description,
            value=value,
            port_value=port_value
        )

        if uuid == None:
            error = True

    api.commit_config(config_uuid)
    api.free_config_lock()
    print("[\033[92;1m+\033[0m] \033[92;1mВыполнено.\033[0m")

