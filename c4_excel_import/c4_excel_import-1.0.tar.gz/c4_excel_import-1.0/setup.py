from setuptools import setup
setup(name = 'c4_excel_import',
    version = '1.0',
    py_modules = ['c4_excel_import'],
    packages = ['c4_excel_import'],
    install_requires = ['c4_lib', 'pandas', 'xlrd', 'openpyxl'],
    include_package_data = True,
    entry_points = {
        'console_scripts': [
                'c4_excel_import = c4_excel_import.__main__:cli',
        ]
    }
)
