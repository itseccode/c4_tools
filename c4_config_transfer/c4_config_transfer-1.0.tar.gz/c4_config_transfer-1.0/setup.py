from setuptools import setup
setup(name = 'c4_config_transfer',
    version = '1.0',
    py_modules = ['c4_config_transfer'],
    packages = ['c4_config_transfer'],
    install_requires = ['c4_lib'],
    include_package_data = True,
    entry_points = {
        'console_scripts': [
                'c4_config_transfer = c4_config_transfer.__main__:cli',
        ]
    }
)
